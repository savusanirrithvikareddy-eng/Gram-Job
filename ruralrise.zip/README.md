# RuralRise (GramJobs: RuralRise Hack)

A bilingual (Hindi / English) skills-based job matching and vocational employment platform built for rural Indian ITI and PMKVY certificate holders and local employers.

## Setup & Run Commands

```bash
npm install
npm run dev
```

- **Dev server (`npm run dev`)**: Starts Express + Vite middleware together on `http://localhost:3000` and auto-seeds `ruralrise.db` (SQLite) with 18 realistic rural/semi-urban technical trade vacancies across 6 states.
- **Production build & start**:
  ```bash
  npm run build
  npm start
  ```
- **Type check (`npm run lint`)**: Runs `tsc --noEmit`.

## Vocational Skill Matching Heuristic

Implemented as a pure function in `client/src/utils/matcher.ts` and shared with the backend via `server/services/skillMatcher.ts`:

```
score = clamp(0, 100, round(requiredPoints + optionalPoints + experienceBonus + certificationBonus))
```

1. **Required Skills (65 pts max)**: Each required skill awards `1.0` credit for an exact match, or `0.5` partial credit if the candidate holds a related skill in the same trade family (e.g. `Electrical Wiring` ↔ `Solar PV Installation`).
2. **Optional / Nice-to-Have Skills (15 pts max)**: Exact matches award `1.0` credit; related trade skills award `0.7` credit.
3. **Experience Bonus (10 pts max)**: Awards up to 10 points when the candidate's relevant trade experience meets (`9.5` pts) or exceeds (`10` pts) the job's minimum experience, gated by skill overlap so unrelated roles never get inflated scores.
4. **ITI / PMKVY Certification Bonus (10 pts max)**: Awards `+10` points when a candidate holds a relevant ITI, PMKVY, or Diploma certificate on a job preferring certification (`+8` otherwise), gated by skill overlap.

## Feature Checklist

- [x] **Vocational Trade Skills Profile Builder**: Icon trade cards across 9 categories, stepper years control (no typing), ITI/PMKVY certification badges, 10-digit phone + simulated OTP (`1234`), and one-tap Demo ITI Profile preset.
- [x] **Regional & Rural Job Directory**: 18 seeded vacancies across Rajasthan, UP, MP, Bihar, Gujarat, and Maharashtra (Rs 10,500–26,500/month), keyword search, trade/district/salary/room filters, and sorting by Best Match, Highest Salary, or Nearest Distance.
- [x] **Algorithmic Vocational Skill Matcher**: Shared pure scoring function (backend + offline LocalStorage fallback) with color-coded match badges and plain-language matched/related/missing skill breakdown.
- [x] **One-Tap Simplified Mobile Application**: Prefilled phone + quick availability selector with instant confirmation and SQLite/LocalStorage persistence.
- [x] **Bilingual Hindi / English Toggle**: Defaults to Hindi (`Noto Sans Devanagari`), instant header toggle switches all labels, trades, skills, job titles, responsibilities, and audio narration.
- [x] **Salary Transparency & Distance**: High-contrast monthly salary + Free Room / Food badges and district-to-district road distance calculation.
- [x] **Voice Audio Job Description Player**: Web SpeechSynthesis (`hi-IN` / `en-IN`) with play/stop controls and missing-voice fallback notice.
- [x] **Direct Employer WhatsApp Connect**: Pre-filled `wa.me/91...` click-to-chat link.
- [x] **Anti-Fraud Protection**: High-contrast "100% Free Job - Never Pay Money to Recruiters" banner + persistent "Report suspicious job" form.
- [x] **Employer Job Posting Form & My Applications Tracker**: Live vacancy posting and application status progression (`Applied` → `Under Review` → `Interview Call` → `Selected` / `Not Selected`).
