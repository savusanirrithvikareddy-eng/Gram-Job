# RuralRise — Vocational Skills & Rural Employment Platform

RuralRise connects rural Indian ITI graduates, PMKVY certificate holders, and village diploma youth with local employers through a resume-free, icon-driven Skill Badge Profile, transparent wage and lodging indicators, and an instant bilingual Hindi/English experience.

## User Review & Critical Decisions

> [!IMPORTANT]
> The product choices below reflect your Phase 1 preferences and will guide the entire build.

- **Default Language & Instant Switch**: Opens in Hindi (`hi`) by default for first-time visitors, with a prominent single-tap Hindi / English toggle in the top header that switches all UI text, skills, trades, job titles, responsibilities, and audio narration while remembering the user's choice.
- **Landing Experience**: Opens directly to the Regional & Rural Job Directory (`Jobs`) alongside a dismissible quick-start skill prompt banner so candidates can immediately browse local openings or jump straight into selecting their trade skills.
- **Demo & Testing Shortcuts**: Includes a one-tap Demo ITI Graduate Profile preset (Jaipur candidate with `Solar PV Installation`, `Electrical Wiring`, and an ITI certificate) plus an in-app "Advance Status" action in `My Applications` to demonstrate the full interview-call lifecycle alongside real backend persistence.

---

## 1. Overview & Core Concept

- **What It Does**: Replaces English-language PDF resumes with a tactile, icon-based Vocational Trade Skills Profile, scores every local job vacancy from 0–100% using a deterministic skill-taxonomy matcher, and lets candidates listen to job details in Hindi/English and apply in one tap using only their verified phone number and availability date.
- **Target Audience / Persona**:
  - *Primary*: Rural ITI and PMKVY trainees or village youth browsing on budget Android smartphones (`360×640` to `412×915`) over slow connections.
  - *Secondary*: Rural enterprises, solar EPC contractors, agri-tech startups, and local distributors posting regional trade openings.
- **Key Value**: Removes language, CV-formatting, and recruiter-fraud barriers through bilingual audio playback, transparent take-home wage + free room/food badges, proximity estimates, and a high-contrast zero-fee anti-fraud guarantee.

---

## 2. User Experience & Visual Design

- **Key User Flows**:
  1. **Discovery & Quick Skill Prompt**: User lands in Hindi on the Job Directory, sees transparent monthly wages and distance badges, and taps either the quick skill prompt or the `My Skills` tab (or activates the one-tap Demo ITI Profile to immediately test the 95% Solar Rooftop Technician Jaipur match).
  2. **Vocational Skill Badge Builder**: User taps large trade category cards (Solar, Electrical, Mechanical, Agri-tech, Welding, Agriculture, Retail, Healthcare, Banking/Finance), selects specific trade skills, adjusts experience years via `+ / −` stepper buttons (zero typing), marks ITI/PMKVY certification, and completes 10-digit phone verification via a simulated 4-digit OTP step alongside home district selection.
  3. **Job Inspection, Audio Playback & Anti-Fraud**: Tapping any job opens its detail view displaying the high-contrast anti-fraud banner (*"100% Free Job — Never Pay Money to Recruiters"*), matched/missing skill breakdown, salary + food/lodging badges, a `Listen to Job` SpeechSynthesis player (`hi-IN` / `en-IN`), a direct WhatsApp click-to-chat link, and a `Report suspicious job` action.
  4. **One-Tap Quick Apply & Tracking**: Tapping `Quick Apply` opens a compact modal prefilled with the verified phone number and a quick availability date selector; one confirmation tap submits the application, shows an instant confirmation toast, and adds it to `My Applications` with live status progression (`Applied` → `Under Review` → `Interview Call` → `Selected` / `Not Selected`).
  5. **Employer Posting**: Local employers switch to `Post a Job`, enter job details, wage, room/food perks, WhatsApp contact, and pick required/optional skills from the same trade taxonomy; the vacancy appears immediately in the directory with live candidate match scores.

- **Visual Identity & Theme**:
  - *Aesthetic Direction*: High-contrast, daylight-legible utility design tailored for budget mobile screens—bold iconography, crisp borders, and clear scannability without heavy hero photography or visual clutter.
  - *Color Palette & Mood* (60-30-10 discipline):
    - `--background`: `#F7F8F5` (warm sunlit off-white canvas, 60%)
    - `--surface`: `#FFFFFF` and `#EEF2EB` (clean cards and subdued surface tints, 30%)
    - `--primary`: `#14532D` (deep rural green for primary navigation, headers, and verified badges)
    - `--accent`: `#D97706` / `#EA580C` (high-visibility saffron/marigold for primary CTAs and key salary/match callouts, 10%)
    - Semantic match indicators (`>=80%` emerald green + label, `50–79%` amber + label, `<50%` neutral slate + label) so state is never conveyed by color alone.
  - *Typography & Hierarchy*: `Plus Jakarta Sans` paired with `Noto Sans Devanagari` for seamless Hindi/English rendering at an accessible `18px` base scale, plus `JetBrains Mono` with `tabular-nums` for salaries, match percentages, phone numbers, and distances. Headlines use `text-wrap: balance`.
  - *Component Styling & Layout*: Mobile-first responsive shell featuring a compact sticky top bar (brand mark + bilingual `हिन्दी / EN` toggle + quick profile indicator) and a fixed 4-tab bottom navigation bar on mobile (`Jobs`, `My Skills`, `Applications`, `Post a Job`) respecting the 15% sticky height cap and minimum `48×48px` touch targets; expands on desktop (`lg:`) into a multi-column grid with top navigation links and comfortable breathing room.

- **Interactive Feedback & Motion**:
  - Instant tactile button press feedback (`<= 200ms`), smooth bottom-sheet/modal transitions using compositor-only `transform`/`opacity`, clear empty states when filters return zero jobs, inline 10-digit phone and OTP validation messages in the active language, and graceful SpeechSynthesis fallback notices when no Hindi voice pack is installed on the device.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Unified Express + Vite Dev Server on Port 3000 with SQLite + LocalStorage Fallback**
  - *Chosen Approach*: Run Express API routes and Vite middleware together on port 3000 backed by `better-sqlite3` (auto-seeded with 18 realistic rural/semi-urban vacancies across 6 states), while mirroring reads/writes in browser `localStorage` if the API is unreachable.
  - *Why*: Ensures `npm run dev` boots the complete full-stack experience in one command with zero CORS issues, while guaranteeing the frontend remains 100% functional even in offline or static-only environments.
  - *Alternatives Considered*: Separate ports with proxy configuration (adds startup fragility) or frontend-only storage (loses real REST endpoints and server-side SQLite persistence).

- **Decision 2: Shared Pure Skill-Matching Heuristic Module**
  - *Chosen Approach*: Implement the weighted skill-overlap, taxonomy-relation, experience, and certification scoring function as a pure TypeScript module shared by both the Express `GET /api/jobs` endpoint and the client fallback.
  - *Why*: Guarantees identical, deterministic `0–100%` scores and plain-language match breakdowns (matched skills, related skills, missing skills) online and offline, calibrated so an ITI candidate with Solar PV Installation + Electrical Wiring scores ~95% on *Solar Rooftop Technician - Jaipur*.
  - *Alternatives Considered*: Server-only scoring (would break offline fallback) or naive keyword matching (fails to award partial credit for related trades like Electrical Wiring and Solar PV).

- **Decision 3: Zero Heavy Media for Rural Bandwidth**
  - *Chosen Approach*: Rely exclusively on crisp Lucide vector icons, Devanagari/Latin typography, and lightweight SVG/CSS indicators instead of raster photographs.
  - *Why*: Keeps bundle size minimal for low-end Android devices and 2G/3G rural networks while maximizing contrast in bright outdoor sunlight.

---

## 4. Technical Architecture & Data Strategy

- **Architecture & Component Diagram**:

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    React Client (Vite + Tailwind + Context)             │
│                                                                         │
│  ┌──────────────────┐  ┌──────────────────┐  ┌───────────────────────┐  │
│  │ LanguageContext  │  │ AppStateContext  │  │ Pure Skill Matcher    │  │
│  │ (hi/en + dict)   │  │ (profile, jobs,  │  │ & District Distance   │  │
│  │                  │  │  apps, fallback) │  │ Lookup                │  │
│  └────────┬─────────┘  └────────┬─────────┘  └───────────┬───────────┘  │
│           │                     │                        │              │
│  ┌────────▼─────────────────────▼────────────────────────▼───────────┐  │
│  │                        Responsive App Shell                       │  │
│  │  Top Header (Brand + HI/EN Toggle) & Bottom/Desktop Nav (4 Tabs)  │  │
│  └──────┬─────────────────┬──────────────────┬──────────────────┬────┘  │
│         │                 │                  │                  │       │
│  ┌──────▼──────┐   ┌──────▼──────┐    ┌──────▼──────┐    ┌──────▼────┐  │
│  │ Job         │   │ Trade Skill │    │ My          │    │ Employer  │  │
│  │ Directory & │   │ Profile     │    │ Applications│    │ Job Post  │  │
│  │ Detail+Audio│   │ Builder+OTP │    │ & Status    │    │ Form      │  │
│  └──────┬──────┘   └──────┬──────┘    └──────┬──────┘    └──────┬────┘  │
└─────────┼─────────────────┼──────────────────┼──────────────────┼───────┘
          │ REST (/api/*)   │                  │                  │
          ▼                 ▼                  ▼                  ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                  Node.js + Express Server (Port 3000)                   │
│                                                                         │
│  GET/POST /api/jobs · GET /api/jobs/:id · POST /api/candidates          │
│  GET/POST /api/applications · PATCH /api/applications/:id               │
│                                                                         │
│  ┌─────────────────────────────────┐  ┌──────────────────────────────┐  │
│  │ Shared Skill Matcher Service    │  │ SQLite (better-sqlite3)      │  │
│  │ (Weighted + Taxonomy + Bonus)   │  │ 18 Seeded Rural Jobs,        │  │
│  │                                 │  │ Candidates, Applications     │  │
│  └─────────────────────────────────┘  └──────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────┘
```

- **Data Model & State**:
  - *Candidate Profile*: `id`, `name`, `phone`, `phoneVerified`, `district`, `state`, `skills[]` (each with `skillId`, `tradeId`, `years`, `certified`, `certificateType`: `ITI` | `PMKVY` | `Diploma`).
  - *Job Vacancy*: `id`, `titleEn`, `titleHi`, `employerName`, `employerType`, `district`, `state`, `tradeCategory`, `requiredSkills[]`, `optionalSkills[]`, `minExperienceYears`, `certificationPreferred`, `monthlySalary`, `foodProvided`, `accommodationProvided`, `responsibilitiesEn[]`, `responsibilitiesHi[]`, `whatsappNumber`, `postedDate`. Seeded with exactly 18 realistic vacancies across Rajasthan, Uttar Pradesh, Madhya Pradesh, Bihar, Gujarat, and Maharashtra (₹9,000–₹28,000).
  - *Job Application*: `id`, `jobId`, `candidateId`, `phone`, `availabilityDate`, `matchScore`, `status` (`Applied` | `Under Review` | `Interview Call` | `Selected` | `Not Selected`), `appliedAt`, `updatedAt`.

- **Interactive Component & State Mapping**:
  - *Skill Matcher Formula*: Required skill overlap (`65` pts max, with `0.5x` partial credit for same-family taxonomy matches) + Optional skill overlap (`15` pts max) + Experience bonus (`+10` pts max if candidate experience meets/exceeds `minExperienceYears`) + Certification bonus (`+10` pts if candidate holds a verified ITI/PMKVY certificate, especially on certification-preferred roles), clamped to `0–100`.
  - *District Proximity Matrix*: Lookup table of coordinates/distances for seeded districts across the 6 states returning `"Same district"` (`0 km`) or approximate highway distance (`e.g. "120 km away"`), driving both badge display and the *"Nearest to home district"* sort mode.
  - *Validation & Error Handling*: Express validates required fields, numeric salary bounds, 10-digit Indian phone numbers, and valid application statuses with `400`/`404`/`500` JSON responses; client forms display accessible inline errors (`aria-invalid`, `aria-describedby`) and seamless LocalStorage fallback if offline.
