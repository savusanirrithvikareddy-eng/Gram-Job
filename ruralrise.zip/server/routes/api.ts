import { Router } from 'express';
import crypto from 'node:crypto';
import {
  createApplication,
  createFraudReport,
  createJob,
  getAllJobs,
  getApplicationsByCandidate,
  getCandidateById,
  getJobById,
  updateApplicationStatus,
  upsertCandidate,
} from '../db/database.ts';
import { enrichJobsForCandidate } from '../services/skillMatcher.ts';
import type {
  ApplicationStatus,
  CandidateProfile,
  JobVacancy,
} from '../../client/src/types/index.ts';

export const apiRouter = Router();

const VALID_STATUSES: ApplicationStatus[] = [
  'Applied',
  'Under Review',
  'Interview Call',
  'Selected',
  'Not Selected',
];

const PHONE_REGEX = /^[6-9]\d{9}$/;

apiRouter.get('/health', (_req, res) => {
  res.json({ ok: true });
});

apiRouter.post('/candidates', (req, res) => {
  try {
    const body = req.body as Partial<CandidateProfile>;
    const name = (body.name ?? '').trim();
    const phone = (body.phone ?? '').replace(/\D/g, '');
    const district = (body.district ?? '').trim();
    const state = (body.state ?? '').trim();
    const skills = Array.isArray(body.skills) ? body.skills : [];

    if (!name || !district || !state) {
      res.status(400).json({ error: 'Name, district, and state are required.' });
      return;
    }

    if (!PHONE_REGEX.test(phone)) {
      res.status(400).json({ error: 'Phone must be a valid 10-digit Indian mobile number.' });
      return;
    }

    const profile: CandidateProfile = {
      id: body.id && body.id.trim() ? body.id.trim() : `cand-${crypto.randomUUID().slice(0, 8)}`,
      name,
      phone,
      phoneVerified: Boolean(body.phoneVerified),
      district,
      state,
      skills: skills.map((s) => ({
        skillId: String(s.skillId),
        tradeId: s.tradeId,
        years: Math.max(0, Math.min(30, Number(s.years) || 0)),
        certified: Boolean(s.certified),
        certificateType: s.certificateType || 'ITI',
      })),
      updatedAt: new Date().toISOString(),
    };

    const saved = upsertCandidate(profile);
    res.status(200).json(saved);
  } catch (err) {
    console.error('POST /api/candidates error:', err);
    res.status(500).json({ error: 'Failed to save candidate profile.' });
  }
});

apiRouter.get('/candidates/:id', (req, res) => {
  try {
    const candidate = getCandidateById(req.params.id);
    if (!candidate) {
      res.status(404).json({ error: 'Candidate profile not found.' });
      return;
    }
    res.json(candidate);
  } catch (err) {
    console.error('GET /api/candidates/:id error:', err);
    res.status(500).json({ error: 'Failed to fetch candidate profile.' });
  }
});

apiRouter.get('/jobs', (req, res) => {
  try {
    const candidateId = typeof req.query.candidateId === 'string' ? req.query.candidateId : '';
    const search = typeof req.query.search === 'string' ? req.query.search.trim().toLowerCase() : '';
    const trade = typeof req.query.trade === 'string' ? req.query.trade.trim() : '';
    const district = typeof req.query.district === 'string' ? req.query.district.trim() : '';
    const minSalary = Number(req.query.minSalary) || 0;
    const accommodationOnly = req.query.accommodationOnly === 'true';
    const sort = typeof req.query.sort === 'string' ? req.query.sort : 'match';

    const candidate = candidateId ? getCandidateById(candidateId) : null;
    let jobs = enrichJobsForCandidate(getAllJobs(), candidate);

    if (search) {
      jobs = jobs.filter(
        (job) =>
          job.titleEn.toLowerCase().includes(search) ||
          job.titleHi.toLowerCase().includes(search) ||
          job.employerName.toLowerCase().includes(search) ||
          job.district.toLowerCase().includes(search) ||
          job.tradeCategory.toLowerCase().includes(search) ||
          job.requiredSkills.some((s) => s.toLowerCase().includes(search))
      );
    }

    if (trade && trade !== 'all') {
      jobs = jobs.filter((job) => job.tradeCategory === trade);
    }

    if (district && district !== 'all') {
      jobs = jobs.filter((job) => job.district.toLowerCase() === district.toLowerCase());
    }

    if (minSalary > 0) {
      jobs = jobs.filter((job) => job.monthlySalary >= minSalary);
    }

    if (accommodationOnly) {
      jobs = jobs.filter((job) => job.accommodationProvided);
    }

    jobs.sort((a, b) => {
      if (sort === 'salary') {
        return b.monthlySalary - a.monthlySalary || b.match.score - a.match.score;
      }
      if (sort === 'distance') {
        const distA = a.distanceKm ?? Number.MAX_SAFE_INTEGER;
        const distB = b.distanceKm ?? Number.MAX_SAFE_INTEGER;
        return distA - distB || b.match.score - a.match.score;
      }
      return b.match.score - a.match.score || b.monthlySalary - a.monthlySalary;
    });

    res.json({ jobs, total: jobs.length });
  } catch (err) {
    console.error('GET /api/jobs error:', err);
    res.status(500).json({ error: 'Failed to load job listings.' });
  }
});

apiRouter.get('/jobs/:id', (req, res) => {
  try {
    const job = getJobById(req.params.id);
    if (!job) {
      res.status(404).json({ error: 'Job vacancy not found.' });
      return;
    }

    const candidateId = typeof req.query.candidateId === 'string' ? req.query.candidateId : '';
    const candidate = candidateId ? getCandidateById(candidateId) : null;
    const [enriched] = enrichJobsForCandidate([job], candidate);
    res.json(enriched);
  } catch (err) {
    console.error('GET /api/jobs/:id error:', err);
    res.status(500).json({ error: 'Failed to load job details.' });
  }
});

apiRouter.post('/jobs', (req, res) => {
  try {
    const body = req.body as Partial<JobVacancy>;
    const titleEn = (body.titleEn ?? '').trim();
    const titleHi = (body.titleHi ?? '').trim() || titleEn;
    const employerName = (body.employerName ?? '').trim();
    const district = (body.district ?? '').trim();
    const state = (body.state ?? '').trim();
    const whatsappNumber = (body.whatsappNumber ?? '').replace(/\D/g, '');
    const monthlySalary = Number(body.monthlySalary);
    const requiredSkills = Array.isArray(body.requiredSkills) ? body.requiredSkills : [];
    const optionalSkills = Array.isArray(body.optionalSkills) ? body.optionalSkills : [];

    if (!titleEn || !employerName || !district || !state || !body.tradeCategory) {
      res.status(400).json({ error: 'Title, employer name, trade, district, and state are required.' });
      return;
    }

    if (!Number.isFinite(monthlySalary) || monthlySalary < 3000 || monthlySalary > 200000) {
      res.status(400).json({ error: 'Monthly salary must be between Rs 3,000 and Rs 2,00,000.' });
      return;
    }

    if (!PHONE_REGEX.test(whatsappNumber)) {
      res.status(400).json({ error: 'WhatsApp number must be a valid 10-digit Indian mobile number.' });
      return;
    }

    if (requiredSkills.length === 0) {
      res.status(400).json({ error: 'Please select at least one required skill.' });
      return;
    }

    const responsibilitiesEn =
      Array.isArray(body.responsibilitiesEn) && body.responsibilitiesEn.length > 0
        ? body.responsibilitiesEn.map((r) => r.trim()).filter(Boolean)
        : ['Perform daily trade tasks safely and report to the site supervisor.'];

    const responsibilitiesHi =
      Array.isArray(body.responsibilitiesHi) && body.responsibilitiesHi.length > 0
        ? body.responsibilitiesHi.map((r) => r.trim()).filter(Boolean)
        : responsibilitiesEn;

    const newJob: JobVacancy = {
      id: `job-${crypto.randomUUID().slice(0, 8)}`,
      titleEn,
      titleHi,
      employerName,
      employerType: body.employerType || 'rural_enterprise',
      district,
      state,
      tradeCategory: body.tradeCategory,
      requiredSkills,
      optionalSkills,
      minExperienceYears: Math.max(0, Math.min(20, Number(body.minExperienceYears) || 0)),
      certificationPreferred: Boolean(body.certificationPreferred),
      monthlySalary: Math.round(monthlySalary),
      foodProvided: Boolean(body.foodProvided),
      accommodationProvided: Boolean(body.accommodationProvided),
      responsibilitiesEn,
      responsibilitiesHi,
      whatsappNumber,
      postedDate: new Date().toISOString().slice(0, 10),
    };

    const saved = createJob(newJob);
    res.status(201).json(saved);
  } catch (err) {
    console.error('POST /api/jobs error:', err);
    res.status(500).json({ error: 'Failed to create job vacancy.' });
  }
});

apiRouter.post('/applications', (req, res) => {
  try {
    const body = req.body as {
      jobId?: string;
      candidateId?: string;
      phone?: string;
      availabilityDate?: string;
      matchScore?: number;
    };

    const jobId = (body.jobId ?? '').trim();
    const candidateId = (body.candidateId ?? '').trim();
    const phone = (body.phone ?? '').replace(/\D/g, '');
    const availabilityDate = (body.availabilityDate ?? '').trim();

    if (!jobId || !candidateId || !availabilityDate) {
      res.status(400).json({ error: 'Job ID, candidate ID, and availability date are required.' });
      return;
    }

    if (!PHONE_REGEX.test(phone)) {
      res.status(400).json({ error: 'Phone number must be a valid 10-digit Indian mobile number.' });
      return;
    }

    const job = getJobById(jobId);
    if (!job) {
      res.status(404).json({ error: 'Target job vacancy not found.' });
      return;
    }

    const now = new Date().toISOString();
    const saved = createApplication({
      id: `app-${crypto.randomUUID().slice(0, 8)}`,
      jobId,
      candidateId,
      phone,
      availabilityDate,
      matchScore: Math.max(0, Math.min(100, Math.round(Number(body.matchScore) || 0))),
      status: 'Applied',
      appliedAt: now,
      updatedAt: now,
    });

    res.status(201).json(saved);
  } catch (err) {
    console.error('POST /api/applications error:', err);
    res.status(500).json({ error: 'Failed to submit application.' });
  }
});

apiRouter.get('/applications', (req, res) => {
  try {
    const candidateId = typeof req.query.candidateId === 'string' ? req.query.candidateId.trim() : '';
    if (!candidateId) {
      res.status(400).json({ error: 'candidateId query parameter is required.' });
      return;
    }

    const applications = getApplicationsByCandidate(candidateId);
    res.json({ applications });
  } catch (err) {
    console.error('GET /api/applications error:', err);
    res.status(500).json({ error: 'Failed to fetch applications.' });
  }
});

apiRouter.patch('/applications/:id', (req, res) => {
  try {
    const status = (req.body as { status?: ApplicationStatus }).status;
    if (!status || !VALID_STATUSES.includes(status)) {
      res.status(400).json({ error: 'Invalid application status.' });
      return;
    }

    const updated = updateApplicationStatus(req.params.id, status);
    if (!updated) {
      res.status(404).json({ error: 'Application not found.' });
      return;
    }

    res.json(updated);
  } catch (err) {
    console.error('PATCH /api/applications/:id error:', err);
    res.status(500).json({ error: 'Failed to update application status.' });
  }
});

apiRouter.post('/reports', (req, res) => {
  try {
    const body = req.body as { jobId?: string; reason?: string; details?: string };
    const jobId = (body.jobId ?? '').trim();
    const reason = (body.reason ?? '').trim();
    if (!jobId || !reason) {
      res.status(400).json({ error: 'Job ID and reason are required.' });
      return;
    }

    const saved = createFraudReport({
      id: `rep-${crypto.randomUUID().slice(0, 8)}`,
      jobId,
      reason,
      details: (body.details ?? '').trim(),
      reportedAt: new Date().toISOString(),
    });
    res.status(201).json(saved);
  } catch (err) {
    console.error('POST /api/reports error:', err);
    res.status(500).json({ error: 'Failed to submit report.' });
  }
});
