import Database from 'better-sqlite3';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { SEED_JOBS } from '../../client/src/data/seedJobs.ts';
import type {
  ApplicationStatus,
  CandidateProfile,
  FraudReport,
  JobApplication,
  JobVacancy,
} from '../../client/src/types/index.ts';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.resolve(__dirname, '../../ruralrise.db');

export const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

export function initDatabase(): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS jobs (
      id TEXT PRIMARY KEY,
      title_en TEXT NOT NULL,
      title_hi TEXT NOT NULL,
      employer_name TEXT NOT NULL,
      employer_type TEXT NOT NULL,
      district TEXT NOT NULL,
      state TEXT NOT NULL,
      trade_category TEXT NOT NULL,
      required_skills_json TEXT NOT NULL,
      optional_skills_json TEXT NOT NULL,
      min_experience_years INTEGER NOT NULL DEFAULT 0,
      certification_preferred INTEGER NOT NULL DEFAULT 0,
      monthly_salary INTEGER NOT NULL,
      food_provided INTEGER NOT NULL DEFAULT 0,
      accommodation_provided INTEGER NOT NULL DEFAULT 0,
      responsibilities_en_json TEXT NOT NULL,
      responsibilities_hi_json TEXT NOT NULL,
      whatsapp_number TEXT NOT NULL,
      posted_date TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS candidates (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      phone TEXT NOT NULL,
      phone_verified INTEGER NOT NULL DEFAULT 0,
      district TEXT NOT NULL,
      state TEXT NOT NULL,
      skills_json TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS applications (
      id TEXT PRIMARY KEY,
      job_id TEXT NOT NULL,
      candidate_id TEXT NOT NULL,
      phone TEXT NOT NULL,
      availability_date TEXT NOT NULL,
      match_score INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'Applied',
      applied_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS fraud_reports (
      id TEXT PRIMARY KEY,
      job_id TEXT NOT NULL,
      reason TEXT NOT NULL,
      details TEXT NOT NULL DEFAULT '',
      reported_at TEXT NOT NULL
    );
  `);

  const countRow = db.prepare('SELECT COUNT(*) as count FROM jobs').get() as { count: number };
  if (countRow.count === 0) {
    const insertJob = db.prepare(`
      INSERT INTO jobs (
        id, title_en, title_hi, employer_name, employer_type, district, state,
        trade_category, required_skills_json, optional_skills_json,
        min_experience_years, certification_preferred, monthly_salary,
        food_provided, accommodation_provided, responsibilities_en_json,
        responsibilities_hi_json, whatsapp_number, posted_date
      ) VALUES (
        @id, @titleEn, @titleHi, @employerName, @employerType, @district, @state,
        @tradeCategory, @requiredSkillsJson, @optionalSkillsJson,
        @minExperienceYears, @certificationPreferred, @monthlySalary,
        @foodProvided, @accommodationProvided, @responsibilitiesEnJson,
        @responsibilitiesHiJson, @whatsappNumber, @postedDate
      )
    `);

    const seedMany = db.transaction((jobs: JobVacancy[]) => {
      for (const job of jobs) {
        insertJob.run({
          id: job.id,
          titleEn: job.titleEn,
          titleHi: job.titleHi,
          employerName: job.employerName,
          employerType: job.employerType,
          district: job.district,
          state: job.state,
          tradeCategory: job.tradeCategory,
          requiredSkillsJson: JSON.stringify(job.requiredSkills),
          optionalSkillsJson: JSON.stringify(job.optionalSkills),
          minExperienceYears: job.minExperienceYears,
          certificationPreferred: job.certificationPreferred ? 1 : 0,
          monthlySalary: job.monthlySalary,
          foodProvided: job.foodProvided ? 1 : 0,
          accommodationProvided: job.accommodationProvided ? 1 : 0,
          responsibilitiesEnJson: JSON.stringify(job.responsibilitiesEn),
          responsibilitiesHiJson: JSON.stringify(job.responsibilitiesHi),
          whatsappNumber: job.whatsappNumber,
          postedDate: job.postedDate,
        });
      }
    });

    seedMany(SEED_JOBS);
  }
}

interface JobRow {
  id: string;
  title_en: string;
  title_hi: string;
  employer_name: string;
  employer_type: JobVacancy['employerType'];
  district: string;
  state: string;
  trade_category: JobVacancy['tradeCategory'];
  required_skills_json: string;
  optional_skills_json: string;
  min_experience_years: number;
  certification_preferred: number;
  monthly_salary: number;
  food_provided: number;
  accommodation_provided: number;
  responsibilities_en_json: string;
  responsibilities_hi_json: string;
  whatsapp_number: string;
  posted_date: string;
}

function mapJobRow(row: JobRow): JobVacancy {
  return {
    id: row.id,
    titleEn: row.title_en,
    titleHi: row.title_hi,
    employerName: row.employer_name,
    employerType: row.employer_type,
    district: row.district,
    state: row.state,
    tradeCategory: row.trade_category,
    requiredSkills: JSON.parse(row.required_skills_json) as string[],
    optionalSkills: JSON.parse(row.optional_skills_json) as string[],
    minExperienceYears: row.min_experience_years,
    certificationPreferred: row.certification_preferred === 1,
    monthlySalary: row.monthly_salary,
    foodProvided: row.food_provided === 1,
    accommodationProvided: row.accommodation_provided === 1,
    responsibilitiesEn: JSON.parse(row.responsibilities_en_json) as string[],
    responsibilitiesHi: JSON.parse(row.responsibilities_hi_json) as string[],
    whatsappNumber: row.whatsapp_number,
    postedDate: row.posted_date,
  };
}

export function getAllJobs(): JobVacancy[] {
  const rows = db.prepare('SELECT * FROM jobs ORDER BY posted_date DESC').all() as JobRow[];
  return rows.map(mapJobRow);
}

export function getJobById(id: string): JobVacancy | null {
  const row = db.prepare('SELECT * FROM jobs WHERE id = ?').get(id) as JobRow | undefined;
  return row ? mapJobRow(row) : null;
}

export function createJob(job: JobVacancy): JobVacancy {
  db.prepare(`
    INSERT INTO jobs (
      id, title_en, title_hi, employer_name, employer_type, district, state,
      trade_category, required_skills_json, optional_skills_json,
      min_experience_years, certification_preferred, monthly_salary,
      food_provided, accommodation_provided, responsibilities_en_json,
      responsibilities_hi_json, whatsapp_number, posted_date
    ) VALUES (
      @id, @titleEn, @titleHi, @employerName, @employerType, @district, @state,
      @tradeCategory, @requiredSkillsJson, @optionalSkillsJson,
      @minExperienceYears, @certificationPreferred, @monthlySalary,
      @foodProvided, @accommodationProvided, @responsibilitiesEnJson,
      @responsibilitiesHiJson, @whatsappNumber, @postedDate
    )
  `).run({
    id: job.id,
    titleEn: job.titleEn,
    titleHi: job.titleHi,
    employerName: job.employerName,
    employerType: job.employerType,
    district: job.district,
    state: job.state,
    tradeCategory: job.tradeCategory,
    requiredSkillsJson: JSON.stringify(job.requiredSkills),
    optionalSkillsJson: JSON.stringify(job.optionalSkills),
    minExperienceYears: job.minExperienceYears,
    certificationPreferred: job.certificationPreferred ? 1 : 0,
    monthlySalary: job.monthlySalary,
    foodProvided: job.foodProvided ? 1 : 0,
    accommodationProvided: job.accommodationProvided ? 1 : 0,
    responsibilitiesEnJson: JSON.stringify(job.responsibilitiesEn),
    responsibilitiesHiJson: JSON.stringify(job.responsibilitiesHi),
    whatsappNumber: job.whatsappNumber,
    postedDate: job.postedDate,
  });

  return job;
}

interface CandidateRow {
  id: string;
  name: string;
  phone: string;
  phone_verified: number;
  district: string;
  state: string;
  skills_json: string;
  updated_at: string;
}

export function upsertCandidate(profile: CandidateProfile): CandidateProfile {
  db.prepare(`
    INSERT INTO candidates (id, name, phone, phone_verified, district, state, skills_json, updated_at)
    VALUES (@id, @name, @phone, @phoneVerified, @district, @state, @skillsJson, @updatedAt)
    ON CONFLICT(id) DO UPDATE SET
      name = excluded.name,
      phone = excluded.phone,
      phone_verified = excluded.phone_verified,
      district = excluded.district,
      state = excluded.state,
      skills_json = excluded.skills_json,
      updated_at = excluded.updated_at
  `).run({
    id: profile.id,
    name: profile.name,
    phone: profile.phone,
    phoneVerified: profile.phoneVerified ? 1 : 0,
    district: profile.district,
    state: profile.state,
    skillsJson: JSON.stringify(profile.skills),
    updatedAt: profile.updatedAt,
  });

  return profile;
}

export function getCandidateById(id: string): CandidateProfile | null {
  const row = db.prepare('SELECT * FROM candidates WHERE id = ?').get(id) as
    | CandidateRow
    | undefined;
  if (!row) return null;
  return {
    id: row.id,
    name: row.name,
    phone: row.phone,
    phoneVerified: row.phone_verified === 1,
    district: row.district,
    state: row.state,
    skills: JSON.parse(row.skills_json),
    updatedAt: row.updated_at,
  };
}

interface ApplicationJoinRow {
  id: string;
  job_id: string;
  candidate_id: string;
  phone: string;
  availability_date: string;
  match_score: number;
  status: ApplicationStatus;
  applied_at: string;
  updated_at: string;
  title_en: string;
  title_hi: string;
  employer_name: string;
  district: string;
  state: string;
  monthly_salary: number;
  accommodation_provided: number;
  whatsapp_number: string;
}

export function createApplication(app: JobApplication): JobApplication {
  const existing = db
    .prepare('SELECT id FROM applications WHERE job_id = ? AND candidate_id = ?')
    .get(app.jobId, app.candidateId) as { id: string } | undefined;

  if (existing) {
    db.prepare(`
      UPDATE applications
      SET phone = ?, availability_date = ?, match_score = ?, updated_at = ?
      WHERE id = ?
    `).run(app.phone, app.availabilityDate, app.matchScore, app.updatedAt, existing.id);

    return getApplicationById(existing.id) ?? app;
  }

  db.prepare(`
    INSERT INTO applications (
      id, job_id, candidate_id, phone, availability_date, match_score, status, applied_at, updated_at
    ) VALUES (
      @id, @jobId, @candidateId, @phone, @availabilityDate, @matchScore, @status, @appliedAt, @updatedAt
    )
  `).run(app);

  return getApplicationById(app.id) ?? app;
}

export function getApplicationById(id: string): JobApplication | null {
  const row = db
    .prepare(`
      SELECT a.*, j.title_en, j.title_hi, j.employer_name, j.district, j.state,
             j.monthly_salary, j.accommodation_provided, j.whatsapp_number
      FROM applications a
      JOIN jobs j ON j.id = a.job_id
      WHERE a.id = ?
    `)
    .get(id) as ApplicationJoinRow | undefined;

  if (!row) return null;
  return {
    id: row.id,
    jobId: row.job_id,
    candidateId: row.candidate_id,
    phone: row.phone,
    availabilityDate: row.availability_date,
    matchScore: row.match_score,
    status: row.status,
    appliedAt: row.applied_at,
    updatedAt: row.updated_at,
    jobTitleEn: row.title_en,
    jobTitleHi: row.title_hi,
    employerName: row.employer_name,
    district: row.district,
    state: row.state,
    monthlySalary: row.monthly_salary,
    accommodationProvided: row.accommodation_provided === 1,
    whatsappNumber: row.whatsapp_number,
  };
}

export function getApplicationsByCandidate(candidateId: string): JobApplication[] {
  const rows = db
    .prepare(`
      SELECT a.*, j.title_en, j.title_hi, j.employer_name, j.district, j.state,
             j.monthly_salary, j.accommodation_provided, j.whatsapp_number
      FROM applications a
      JOIN jobs j ON j.id = a.job_id
      WHERE a.candidate_id = ?
      ORDER BY a.applied_at DESC
    `)
    .all(candidateId) as ApplicationJoinRow[];

  return rows.map((row) => ({
    id: row.id,
    jobId: row.job_id,
    candidateId: row.candidate_id,
    phone: row.phone,
    availabilityDate: row.availability_date,
    matchScore: row.match_score,
    status: row.status,
    appliedAt: row.applied_at,
    updatedAt: row.updated_at,
    jobTitleEn: row.title_en,
    jobTitleHi: row.title_hi,
    employerName: row.employer_name,
    district: row.district,
    state: row.state,
    monthlySalary: row.monthly_salary,
    accommodationProvided: row.accommodation_provided === 1,
    whatsappNumber: row.whatsapp_number,
  }));
}

export function updateApplicationStatus(
  id: string,
  status: ApplicationStatus
): JobApplication | null {
  const result = db
    .prepare('UPDATE applications SET status = ?, updated_at = ? WHERE id = ?')
    .run(status, new Date().toISOString(), id);

  if (result.changes === 0) return null;
  return getApplicationById(id);
}

export function createFraudReport(report: FraudReport): FraudReport {
  db.prepare(`
    INSERT INTO fraud_reports (id, job_id, reason, details, reported_at)
    VALUES (@id, @jobId, @reason, @details, @reportedAt)
  `).run(report);
  return report;
}
