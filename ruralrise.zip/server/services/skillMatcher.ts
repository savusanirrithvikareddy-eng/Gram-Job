import { computeDistrictDistanceKm } from '../../client/src/data/districts.ts';
import { computeSkillMatch } from '../../client/src/utils/matcher.ts';
import type {
  CandidateProfile,
  JobVacancy,
  JobWithMatch,
} from '../../client/src/types/index.ts';

export { computeSkillMatch };

export function enrichJobsForCandidate(
  jobs: JobVacancy[],
  candidate: CandidateProfile | null
): JobWithMatch[] {
  return jobs.map((job) => ({
    ...job,
    match: computeSkillMatch(candidate?.skills ?? [], job),
    distanceKm: candidate?.district
      ? computeDistrictDistanceKm(candidate.district, job.district)
      : null,
  }));
}
