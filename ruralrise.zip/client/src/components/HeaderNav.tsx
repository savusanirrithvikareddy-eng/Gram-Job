import { Award, Briefcase, ClipboardList, Languages, PlusCircle, Sprout } from 'lucide-react';
import { useAppState, type NavTab } from '../context/AppStateContext.tsx';
import { useLanguage } from '../context/LanguageContext.tsx';

export function HeaderNav() {
  const { lang, toggleLang, t } = useLanguage();
  const { activeTab, setActiveTab, applications, candidate, setSelectedJob } = useAppState();

  const navItems: Array<{ id: NavTab; label: string; icon: typeof Briefcase; badge?: number }> = [
    { id: 'jobs', label: t.navJobs, icon: Briefcase },
    { id: 'skills', label: t.navSkills, icon: Award, badge: candidate.skills.length || undefined },
    {
      id: 'applications',
      label: t.navApplications,
      icon: ClipboardList,
      badge: applications.length || undefined,
    },
    { id: 'post', label: t.navPostJob, icon: PlusCircle },
  ];

  const handleNavClick = (tab: NavTab) => {
    setSelectedJob(null);
    setActiveTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      <header className="bg-white border-b border-slate-200 md:sticky md:top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          <button
            type="button"
            onClick={() => handleNavClick('jobs')}
            className="flex items-center gap-2.5 text-left min-h-[48px] shrink-0"
          >
            <span className="w-10 h-10 rounded-xl bg-green-900 text-white flex items-center justify-center shrink-0">
              <Sprout className="w-6 h-6" aria-hidden="true" />
            </span>
            <span className="text-xl font-bold tracking-tight text-green-950 whitespace-nowrap">
              {t.brandName}
            </span>
          </button>

          <nav
            aria-label="Primary"
            className="hidden md:flex items-center gap-6 text-base font-medium text-slate-700"
          >
            {navItems.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => handleNavClick(item.id)}
                  aria-current={isActive ? 'page' : undefined}
                  className={`min-h-[48px] px-2 flex items-center gap-2 whitespace-nowrap shrink-0 border-b-2 transition-colors ${
                    isActive
                      ? 'border-green-800 text-green-900 font-semibold'
                      : 'border-transparent text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <item.icon className="w-5 h-5" aria-hidden="true" />
                  <span>{item.label}</span>
                  {item.badge !== undefined && (
                    <span className="font-mono-nums text-xs px-1.5 py-0.5 rounded bg-green-100 text-green-900 font-semibold">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          <button
            type="button"
            onClick={toggleLang}
            aria-label={lang === 'hi' ? 'Switch language to English' : 'भाषा हिन्दी में बदलें'}
            className="min-h-[48px] px-3.5 py-2 rounded-xl border-2 border-green-800 bg-green-50 text-green-950 hover:bg-green-100 font-semibold text-sm flex items-center gap-2 whitespace-nowrap shrink-0 transition-colors"
          >
            <Languages className="w-5 h-5 text-green-800" aria-hidden="true" />
            <span>{lang === 'hi' ? t.langSwitchToEn : t.langSwitchToHi}</span>
          </button>
        </div>
      </header>

      <nav
        aria-label="Mobile Navigation"
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-slate-200 shadow-[0_-2px_10px_rgba(0,0,0,0.06)]"
      >
        <div className="grid grid-cols-4 h-16">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleNavClick(item.id)}
                aria-current={isActive ? 'page' : undefined}
                className={`relative flex flex-col items-center justify-center min-h-[48px] px-1 transition-colors ${
                  isActive ? 'text-green-900 font-semibold bg-green-50/70' : 'text-slate-600'
                }`}
              >
                <div className="relative">
                  <Icon className="w-5 h-5" aria-hidden="true" />
                  {item.badge !== undefined && (
                    <span className="font-mono-nums absolute -top-1.5 -right-2.5 min-w-[18px] h-[18px] px-1 rounded-full bg-amber-600 text-white text-[10px] font-bold flex items-center justify-center">
                      {item.badge}
                    </span>
                  )}
                </div>
                <span className="text-[11px] leading-tight mt-1 truncate max-w-full">
                  {item.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>
    </>
  );
}
