import {
  Award,
  BedDouble,
  CheckCircle2,
  MapPin,
  Navigation,
  Utensils,
} from 'lucide-react';
import { useAppState } from '../context/AppStateContext.tsx';
import { useLanguage } from '../context/LanguageContext.tsx';
import { getDistrictLabel, getStateLabel } from '../data/districts.ts';
import { getSkillLabel, getTradeLabel } from '../data/taxonomy.ts';
import { EMPLOYER_TYPE_LABELS, formatRupees } from '../i18n/translations.ts';
import type { JobWithMatch } from '../types/index.ts';
import { TradeIcon } from './TradeIcon.tsx';

interface JobCardProps {
  job: JobWithMatch;
}

export function JobCard({ job }: JobCardProps) {
  const { lang, t } = useLanguage();
  const { candidate, appliedJobIds, setSelectedJob, setApplyModalJob } = useAppState();

  const hasSkills = candidate.skills.length > 0;
  const isApplied = appliedJobIds.has(job.id);
  const title = lang === 'hi' ? job.titleHi : job.titleEn;
  const employerTypeLabel = EMPLOYER_TYPE_LABELS[job.employerType][lang];
  const tradeLabel = getTradeLabel(job.tradeCategory, lang);
  const districtLabel = getDistrictLabel(job.district, lang);
  const stateLabel = getStateLabel(job.state, lang);

  const matchScore = job.match.score;
  const matchColor =
    matchScore >= 80
      ? 'bg-emerald-900 text-white'
      : matchScore >= 50
      ? 'bg-amber-600 text-white'
      : 'bg-slate-700 text-white';

  const salaryLine = `${formatRupees(job.monthlySalary, lang)}${t.perMonth}${
    job.accommodationProvided ? ` + ${t.freeRoom}` : ''
  }`;

  const distanceText =
    job.distanceKm === null
      ? t.setHomeDistrictHint
      : job.distanceKm === 0
      ? t.sameDistrict
      : `${job.distanceKm} ${t.kmAway}`;

  return (
    <article className="bg-white rounded-2xl border border-slate-200 p-5 flex flex-col justify-between gap-4 shadow-sm hover:border-green-700 transition-colors">
      <div className="space-y-3">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-3 min-w-0">
            <div className="w-12 h-12 rounded-xl bg-green-50 border border-green-200 text-green-900 flex items-center justify-center shrink-0">
              <TradeIcon tradeId={job.tradeCategory} className="w-6 h-6" />
            </div>
            <div className="min-w-0">
              <p className="text-xs font-medium text-slate-600 truncate">
                {tradeLabel} · {employerTypeLabel}
              </p>
              <h2 className="text-lg font-bold text-slate-950 leading-snug">{title}</h2>
              <p className="text-sm font-medium text-slate-700 truncate">{job.employerName}</p>
            </div>
          </div>

          {hasSkills && (
            <div
              className={`font-mono-nums px-3 py-1.5 rounded-xl text-sm font-bold shrink-0 flex items-center gap-1 ${matchColor}`}
              aria-label={`${matchScore}% ${t.matchBadge}`}
            >
              <span>{matchScore}%</span>
              <span className="font-sans text-xs font-semibold">{t.matchBadge}</span>
            </div>
          )}
        </div>

        <div className="bg-amber-50 border border-amber-200 rounded-xl px-3.5 py-2.5 flex items-center justify-between gap-2 flex-wrap">
          <span className="font-mono-nums text-base sm:text-lg font-bold text-slate-950">
            {salaryLine}
          </span>
        </div>

        <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-sm text-slate-700">
          <span className="inline-flex items-center gap-1.5">
            <MapPin className="w-4 h-4 text-green-800 shrink-0" aria-hidden="true" />
            <span>
              {districtLabel}, {stateLabel}
            </span>
          </span>
          <span className="inline-flex items-center gap-1.5 font-mono-nums text-slate-700">
            <Navigation className="w-4 h-4 text-amber-700 shrink-0" aria-hidden="true" />
            <span>{distanceText}</span>
          </span>
        </div>

        <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-sm text-slate-700">
          {job.accommodationProvided && (
            <span className="inline-flex items-center gap-1.5 text-green-900 font-medium">
              <BedDouble className="w-4 h-4" aria-hidden="true" />
              <span>{t.freeRoom}</span>
            </span>
          )}
          {job.foodProvided && (
            <span className="inline-flex items-center gap-1.5 text-green-900 font-medium">
              <Utensils className="w-4 h-4" aria-hidden="true" />
              <span>{t.freeFood}</span>
            </span>
          )}
          {job.certificationPreferred && (
            <span className="inline-flex items-center gap-1.5 text-slate-700">
              <Award className="w-4 h-4 text-amber-700" aria-hidden="true" />
              <span>{t.certPreferred}</span>
            </span>
          )}
        </div>

        {hasSkills && (
          <div className="pt-2 border-t border-slate-100 text-xs sm:text-sm space-y-1">
            {job.match.matchedSkills.length > 0 && (
              <p className="text-emerald-900">
                <strong className="font-semibold">{t.matchedSkillsLabel}:</strong>{' '}
                {job.match.matchedSkills.map((id) => getSkillLabel(id, lang)).join(', ')}
              </p>
            )}
            {job.match.missingSkills.length > 0 && (
              <p className="text-slate-600">
                <strong className="font-semibold">{t.missingSkillsLabel}:</strong>{' '}
                {job.match.missingSkills.map((id) => getSkillLabel(id, lang)).join(', ')}
              </p>
            )}
          </div>
        )}
      </div>

      <div className="grid grid-cols-2 gap-2.5 pt-2">
        <button
          type="button"
          onClick={() => setSelectedJob(job)}
          className="min-h-[48px] px-3 py-2.5 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 text-slate-900 font-semibold text-sm sm:text-base transition-colors"
        >
          {t.viewDetails}
        </button>

        <button
          type="button"
          onClick={() => setApplyModalJob(job)}
          className={`min-h-[48px] px-3 py-2.5 rounded-xl font-semibold text-sm sm:text-base flex items-center justify-center gap-1.5 transition-colors ${
            isApplied
              ? 'bg-emerald-100 text-emerald-950 border border-emerald-300'
              : 'bg-amber-600 hover:bg-amber-700 text-white'
          }`}
        >
          {isApplied && <CheckCircle2 className="w-4 h-4" aria-hidden="true" />}
          <span>{isApplied ? t.appliedTag : t.quickApply}</span>
        </button>
      </div>
    </article>
  );
}
