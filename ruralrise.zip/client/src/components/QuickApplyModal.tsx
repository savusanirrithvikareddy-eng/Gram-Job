import { Calendar, CheckCircle2, Phone, X } from 'lucide-react';
import React, { useEffect, useState } from 'react';
import { useAppState } from '../context/AppStateContext.tsx';
import { useLanguage } from '../context/LanguageContext.tsx';
import { formatRupees } from '../i18n/translations.ts';

const PHONE_REGEX = /^[6-9]\d{9}$/;

function addDaysIso(days: number): string {
  const date = new Date();
  date.setDate(date.getDate() + days);
  return date.toISOString().slice(0, 10);
}

export function QuickApplyModal() {
  const { lang, t } = useLanguage();
  const { applyModalJob, setApplyModalJob, candidate, applyToJob } = useAppState();

  const [phone, setPhone] = useState(candidate.phone || '');
  const [availabilityDate, setAvailabilityDate] = useState(addDaysIso(0));
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (applyModalJob) {
      setPhone(candidate.phone || '');
      setAvailabilityDate(addDaysIso(0));
      setError(null);
    }
  }, [applyModalJob, candidate.phone]);

  if (!applyModalJob) return null;

  const title = lang === 'hi' ? applyModalJob.titleHi : applyModalJob.titleEn;

  const quickDates = [
    { label: t.availabilityImmediate, value: addDaysIso(0) },
    { label: t.availabilityNextWeek, value: addDaysIso(7) },
    { label: t.availabilityMonthStart, value: addDaysIso(30) },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanedPhone = phone.replace(/\D/g, '');
    if (!PHONE_REGEX.test(cleanedPhone)) {
      setError(t.invalidPhoneError);
      return;
    }

    setSubmitting(true);
    setError(null);
    await applyToJob(applyModalJob, cleanedPhone, availabilityDate);
    setSubmitting(false);
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="quick-apply-title"
    >
      <div className="bg-white w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl overflow-hidden shadow-2xl">
        <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between gap-3">
          <div>
            <h2 id="quick-apply-title" className="text-lg font-bold text-slate-950">
              {t.quickApplyTitle}
            </h2>
            <p className="text-sm text-slate-600 truncate">
              {title} · {formatRupees(applyModalJob.monthlySalary, lang)}
              {t.perMonth}
            </p>
          </div>

          <button
            type="button"
            onClick={() => setApplyModalJob(null)}
            aria-label={t.close}
            className="min-w-[48px] min-h-[48px] rounded-xl border border-slate-200 flex items-center justify-center text-slate-700 hover:bg-slate-100"
          >
            <X className="w-5 h-5" aria-hidden="true" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-5">
          <p className="text-sm text-green-900 bg-green-50 border border-green-200 rounded-xl p-3">
            {t.quickApplySubtitle}
          </p>

          <div>
            <label htmlFor="quick-apply-phone" className="block text-sm font-bold text-slate-900 mb-1.5">
              {t.phoneLabel}
            </label>
            <div className="relative">
              <Phone
                className="w-5 h-5 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2"
                aria-hidden="true"
              />
              <input
                id="quick-apply-phone"
                type="tel"
                inputMode="numeric"
                maxLength={10}
                value={phone}
                onChange={(e) => setPhone(e.target.value.replace(/\D/g, '').slice(0, 10))}
                placeholder={t.phonePlaceholder}
                aria-invalid={Boolean(error)}
                aria-describedby={error ? 'quick-apply-phone-error' : undefined}
                className="font-mono-nums w-full min-h-[52px] pl-11 pr-4 rounded-xl border-2 border-slate-300 bg-white text-lg text-slate-950 focus:border-green-800"
                required
              />
            </div>
            {error && (
              <p id="quick-apply-phone-error" className="mt-1.5 text-sm font-semibold text-red-700">
                {error}
              </p>
            )}
          </div>

          <fieldset className="space-y-2.5">
            <legend className="text-sm font-bold text-slate-900">{t.availabilityLabel}</legend>
            <div className="grid grid-cols-3 gap-2">
              {quickDates.map((qd) => {
                const active = availabilityDate === qd.value;
                return (
                  <button
                    key={qd.value}
                    type="button"
                    onClick={() => setAvailabilityDate(qd.value)}
                    className={`min-h-[48px] px-2 py-2 rounded-xl border text-xs sm:text-sm font-semibold transition-colors ${
                      active
                        ? 'bg-green-900 text-white border-green-900'
                        : 'bg-white text-slate-800 border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    {qd.label}
                  </button>
                );
              })}
            </div>
            <div className="relative">
              <Calendar
                className="w-5 h-5 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
                aria-hidden="true"
              />
              <input
                type="date"
                aria-label={t.availabilityLabel}
                value={availabilityDate}
                onChange={(e) => setAvailabilityDate(e.target.value)}
                className="font-mono-nums w-full min-h-[48px] pl-11 pr-4 rounded-xl border border-slate-300 bg-white text-base text-slate-900"
              />
            </div>
          </fieldset>

          <button
            type="submit"
            disabled={submitting}
            className="w-full min-h-[52px] px-5 py-3 rounded-xl bg-amber-600 hover:bg-amber-700 disabled:opacity-60 text-white font-bold text-lg flex items-center justify-center gap-2 transition-colors"
          >
            <CheckCircle2 className="w-5 h-5" aria-hidden="true" />
            <span>{t.confirmApplyBtn}</span>
          </button>
        </form>
      </div>
    </div>
  );
}
