import {
  Award,
  BedDouble,
  CheckCircle2,
  Flag,
  MapPin,
  MessageCircle,
  Navigation,
  ShieldAlert,
  Utensils,
  X,
} from 'lucide-react';
import React, { useState } from 'react';
import { useAppState } from '../context/AppStateContext.tsx';
import { useLanguage } from '../context/LanguageContext.tsx';
import { getDistrictLabel, getStateLabel } from '../data/districts.ts';
import { getSkillLabel, getTradeLabel } from '../data/taxonomy.ts';
import { EMPLOYER_TYPE_LABELS, formatRupees } from '../i18n/translations.ts';
import { submitReportApi } from '../utils/apiClient.ts';
import { TradeIcon } from './TradeIcon.tsx';
import { VoiceJobPlayer } from './VoiceJobPlayer.tsx';

export function JobDetailModal() {
  const { lang, t } = useLanguage();
  const {
    selectedJob,
    setSelectedJob,
    setApplyModalJob,
    appliedJobIds,
    candidate,
    showToast,
  } = useAppState();

  const [reportOpen, setReportOpen] = useState(false);
  const [reportReason, setReportReason] = useState<string>(t.reportReasons[0]);
  const [reportDetails, setReportDetails] = useState('');

  if (!selectedJob) return null;

  const job = selectedJob;
  const title = lang === 'hi' ? job.titleHi : job.titleEn;
  const responsibilities = lang === 'hi' ? job.responsibilitiesHi : job.responsibilitiesEn;
  const districtLabel = getDistrictLabel(job.district, lang);
  const stateLabel = getStateLabel(job.state, lang);
  const isApplied = appliedJobIds.has(job.id);
  const hasSkills = candidate.skills.length > 0;

  const whatsappMessage =
    lang === 'hi'
      ? `नमस्ते, मुझे RuralRise पर "${job.titleHi}" नौकरी के लिए आवेदन करना है।${
          candidate.name ? ` मेरा नाम ${candidate.name} है।` : ''
        }`
      : `Hello, I am interested in the "${job.titleEn}" job on RuralRise.${
          candidate.name ? ` My name is ${candidate.name}.` : ''
        }`;

  const whatsappUrl = `https://wa.me/91${job.whatsappNumber}?text=${encodeURIComponent(
    whatsappMessage
  )}`;

  const distanceText =
    job.distanceKm === null
      ? t.setHomeDistrictHint
      : job.distanceKm === 0
      ? t.sameDistrict
      : `${job.distanceKm} ${t.kmAway}`;

  const handleReportSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await submitReportApi(job.id, reportReason, reportDetails);
    setReportOpen(false);
    setReportDetails('');
    showToast(t.reportSuccess, 'info');
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="job-detail-title"
    >
      <div className="bg-white w-full sm:max-w-2xl max-h-[92vh] rounded-t-3xl sm:rounded-2xl overflow-hidden flex flex-col shadow-2xl">
        <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between gap-3 bg-white shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <span className="w-10 h-10 rounded-xl bg-green-50 border border-green-200 text-green-900 flex items-center justify-center shrink-0">
              <TradeIcon tradeId={job.tradeCategory} className="w-5 h-5" />
            </span>
            <div className="min-w-0">
              <p className="text-xs text-slate-600 truncate">
                {getTradeLabel(job.tradeCategory, lang)} · {EMPLOYER_TYPE_LABELS[job.employerType][lang]}
              </p>
              <h2 id="job-detail-title" className="text-lg sm:text-xl font-bold text-slate-950 truncate">
                {title}
              </h2>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setSelectedJob(null)}
            aria-label={t.close}
            className="min-w-[48px] min-h-[48px] rounded-xl border border-slate-200 flex items-center justify-center text-slate-700 hover:bg-slate-100 shrink-0"
          >
            <X className="w-5 h-5" aria-hidden="true" />
          </button>
        </div>

        <div className="p-5 overflow-y-auto space-y-5">
          {/* Anti-Fraud High-Contrast Banner */}
          <div className="bg-red-50 border-2 border-red-700 rounded-2xl p-4 space-y-2">
            <div className="flex items-start gap-3">
              <ShieldAlert className="w-6 h-6 text-red-700 shrink-0 mt-0.5" aria-hidden="true" />
              <div className="space-y-1">
                <p className="font-bold text-red-950 text-base leading-snug">{t.antiFraudTitle}</p>
                <p className="text-sm text-red-900">{t.antiFraudSubtitle}</p>
              </div>
            </div>
            <div>
              <button
                type="button"
                onClick={() => setReportOpen((prev) => !prev)}
                className="text-sm font-semibold text-red-800 underline hover:text-red-950 inline-flex items-center gap-1.5 min-h-[40px]"
              >
                <Flag className="w-4 h-4" aria-hidden="true" />
                <span>{t.reportSuspicious}</span>
              </button>
            </div>

            {reportOpen && (
              <form
                onSubmit={handleReportSubmit}
                className="mt-2 pt-3 border-t border-red-200 space-y-3"
              >
                <h3 className="font-bold text-sm text-red-950">{t.reportModalTitle}</h3>
                <div>
                  <label htmlFor="report-reason" className="block text-xs font-semibold text-red-950 mb-1">
                    {t.reportReasonLabel}
                  </label>
                  <select
                    id="report-reason"
                    value={reportReason}
                    onChange={(e) => setReportReason(e.target.value)}
                    className="w-full min-h-[48px] px-3 rounded-xl border border-red-300 bg-white text-sm text-slate-900"
                  >
                    {t.reportReasons.map((reason) => (
                      <option key={reason} value={reason}>
                        {reason}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label htmlFor="report-details" className="block text-xs font-semibold text-red-950 mb-1">
                    {t.reportDetailsLabel}
                  </label>
                  <textarea
                    id="report-details"
                    rows={2}
                    value={reportDetails}
                    onChange={(e) => setReportDetails(e.target.value)}
                    placeholder={t.reportDetailsPlaceholder}
                    className="w-full p-3 rounded-xl border border-red-300 bg-white text-sm text-slate-900"
                  />
                </div>
                <div className="flex gap-2">
                  <button
                    type="submit"
                    className="min-h-[44px] px-4 py-2 rounded-xl bg-red-700 text-white text-sm font-semibold hover:bg-red-800"
                  >
                    {t.submitReport}
                  </button>
                  <button
                    type="button"
                    onClick={() => setReportOpen(false)}
                    className="min-h-[44px] px-4 py-2 rounded-xl bg-white border border-red-200 text-red-900 text-sm font-semibold"
                  >
                    {t.cancel}
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* Wage & Logistics Summary */}
          <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <div>
                <p className="text-sm font-medium text-slate-700">{job.employerName}</p>
                <p className="font-mono-nums text-xl font-bold text-slate-950">
                  {formatRupees(job.monthlySalary, lang)}
                  {t.perMonth}
                  {job.accommodationProvided ? ` + ${t.freeRoom}` : ''}
                </p>
              </div>
              {hasSkills && (
                <span className="font-mono-nums px-3.5 py-2 rounded-xl bg-green-900 text-white font-bold text-base">
                  {job.match.score}% {t.matchBadge}
                </span>
              )}
            </div>

            <div className="flex flex-wrap gap-3 text-sm text-slate-800">
              <span className="inline-flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-green-800" aria-hidden="true" />
                {districtLabel}, {stateLabel}
              </span>
              <span className="inline-flex items-center gap-1.5 font-mono-nums">
                <Navigation className="w-4 h-4 text-amber-700" aria-hidden="true" />
                {distanceText}
              </span>
              {job.accommodationProvided && (
                <span className="inline-flex items-center gap-1.5 font-semibold text-green-900">
                  <BedDouble className="w-4 h-4" aria-hidden="true" />
                  {t.freeRoom}
                </span>
              )}
              {job.foodProvided && (
                <span className="inline-flex items-center gap-1.5 font-semibold text-green-900">
                  <Utensils className="w-4 h-4" aria-hidden="true" />
                  {t.freeFood}
                </span>
              )}
              {job.certificationPreferred && (
                <span className="inline-flex items-center gap-1.5 font-medium text-slate-800">
                  <Award className="w-4 h-4 text-amber-700" aria-hidden="true" />
                  {t.certPreferred}
                </span>
              )}
            </div>
          </div>

          {/* Voice Audio Player */}
          <VoiceJobPlayer job={job} />

          {/* Match Breakdown */}
          {hasSkills && (
            <section className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-2.5">
              <h3 className="text-base font-bold text-slate-900">{t.skillBreakdownTitle}</h3>
              <div className="text-sm space-y-1.5">
                <p className="text-emerald-900">
                  <strong>{t.matchedSkillsLabel}:</strong>{' '}
                  {job.match.matchedSkills.length > 0
                    ? job.match.matchedSkills.map((id) => getSkillLabel(id, lang)).join(', ')
                    : '—'}
                </p>
                {job.match.relatedSkills.length > 0 && (
                  <p className="text-amber-900">
                    <strong>{t.relatedSkillsLabel}:</strong>{' '}
                    {job.match.relatedSkills.map((id) => getSkillLabel(id, lang)).join(', ')}
                  </p>
                )}
                {job.match.missingSkills.length > 0 && (
                  <p className="text-slate-700">
                    <strong>{t.missingSkillsLabel}:</strong>{' '}
                    {job.match.missingSkills.map((id) => getSkillLabel(id, lang)).join(', ')}
                  </p>
                )}
                <p className="text-slate-700 font-mono-nums">
                  {t.expBonusLabel}: +{job.match.experienceBonus}% · {t.certBonusLabel}: +
                  {job.match.certificationBonus}%
                </p>
              </div>
            </section>
          )}

          {/* Responsibilities */}
          <section className="space-y-2">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <h3 className="text-base font-bold text-slate-950">{t.responsibilitiesTitle}</h3>
              <span className="text-sm text-slate-600 font-medium">
                {t.minExperienceLabel}:{' '}
                {job.minExperienceYears === 0
                  ? t.fresherOk
                  : `${job.minExperienceYears}+ ${t.yearsUnit}`}
              </span>
            </div>
            <ul className="list-disc pl-5 space-y-2 text-base text-slate-800">
              {responsibilities.map((item, idx) => (
                <li key={idx}>{item}</li>
              ))}
            </ul>
          </section>
        </div>

        <div className="p-4 border-t border-slate-200 bg-white flex flex-col sm:flex-row gap-3 shrink-0">
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="min-h-[48px] flex-1 px-4 py-3 rounded-xl border-2 border-emerald-700 text-emerald-900 bg-emerald-50 hover:bg-emerald-100 font-semibold text-base flex items-center justify-center gap-2 transition-colors"
          >
            <MessageCircle className="w-5 h-5" aria-hidden="true" />
            <span>{t.whatsappConnect}</span>
          </a>

          <button
            type="button"
            onClick={() => setApplyModalJob(job)}
            className={`min-h-[48px] flex-1 px-4 py-3 rounded-xl font-bold text-base flex items-center justify-center gap-2 transition-colors ${
              isApplied
                ? 'bg-emerald-700 text-white hover:bg-emerald-800'
                : 'bg-amber-600 text-white hover:bg-amber-700'
            }`}
          >
            {isApplied && <CheckCircle2 className="w-5 h-5" aria-hidden="true" />}
            <span>{isApplied ? t.appliedTag : t.quickApply}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
