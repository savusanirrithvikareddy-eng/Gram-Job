import { Volume2, Square, Info } from 'lucide-react';
import { useEffect, useState } from 'react';
import { useLanguage } from '../context/LanguageContext.tsx';
import { getDistrictLabel, getStateLabel } from '../data/districts.ts';
import { formatRupees } from '../i18n/translations.ts';
import type { JobVacancy } from '../types/index.ts';

interface VoiceJobPlayerProps {
  job: JobVacancy;
}

export function VoiceJobPlayer({ job }: VoiceJobPlayerProps) {
  const { lang, t } = useLanguage();
  const [isPlaying, setIsPlaying] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);

  const supported = typeof window !== 'undefined' && 'speechSynthesis' in window;

  useEffect(() => {
    return () => {
      if (supported) {
        window.speechSynthesis.cancel();
      }
    };
  }, [supported, job.id, lang]);

  const stopPlayback = () => {
    if (!supported) return;
    window.speechSynthesis.cancel();
    setIsPlaying(false);
  };

  const handleTogglePlay = () => {
    if (!supported) {
      setNotice(t.audioUnsupported);
      return;
    }

    if (isPlaying) {
      stopPlayback();
      return;
    }

    setNotice(null);
    window.speechSynthesis.cancel();

    const district = getDistrictLabel(job.district, lang);
    const state = getStateLabel(job.state, lang);
    const salaryText = formatRupees(job.monthlySalary, lang);

    const script =
      lang === 'hi'
        ? [
            `नौकरी का नाम: ${job.titleHi}।`,
            `कंपनी: ${job.employerName}, स्थान: ${district}, ${state}।`,
            `मासिक वेतन: ${salaryText} प्रतिमाह।`,
            job.accommodationProvided ? 'मुफ्त रहने का कमरा उपलब्ध है।' : '',
            job.foodProvided ? 'मुफ्त भोजन की सुविधा भी उपलब्ध है।' : '',
            `मुख्य कार्य: ${job.responsibilitiesHi.join(' ')}`,
          ]
            .filter(Boolean)
            .join(' ')
        : [
            `Job title: ${job.titleEn}.`,
            `Employer: ${job.employerName}, located in ${district}, ${state}.`,
            `Monthly salary: ${salaryText} per month.`,
            job.accommodationProvided ? 'Free accommodation is provided.' : '',
            job.foodProvided ? 'Free food is provided.' : '',
            `Responsibilities: ${job.responsibilitiesEn.join(' ')}`,
          ]
            .filter(Boolean)
            .join(' ');

    const utterance = new SpeechSynthesisUtterance(script);
    const targetLang = lang === 'hi' ? 'hi-IN' : 'en-IN';
    utterance.lang = targetLang;
    utterance.rate = 0.95;

    const voices = window.speechSynthesis.getVoices();
    if (voices.length > 0) {
      const exactVoice = voices.find((v) => v.lang.toLowerCase().startsWith(lang));
      if (exactVoice) {
        utterance.voice = exactVoice;
      } else if (lang === 'hi') {
        setNotice(t.audioNoHindiVoice);
      }
    }

    utterance.onend = () => setIsPlaying(false);
    utterance.onerror = () => setIsPlaying(false);

    setIsPlaying(true);
    window.speechSynthesis.speak(utterance);
  };

  return (
    <div className="space-y-2">
      <button
        type="button"
        onClick={handleTogglePlay}
        aria-pressed={isPlaying}
        className={`w-full sm:w-auto min-h-[48px] px-5 py-3 rounded-xl font-semibold text-base flex items-center justify-center gap-2.5 transition-colors ${
          isPlaying
            ? 'bg-amber-600 text-white hover:bg-amber-700'
            : 'bg-green-900 text-white hover:bg-green-800'
        }`}
      >
        {isPlaying ? (
          <>
            <Square className="w-5 h-5 fill-current" aria-hidden="true" />
            <span>{t.stopListening}</span>
          </>
        ) : (
          <>
            <Volume2 className="w-5 h-5" aria-hidden="true" />
            <span>{t.listenToJob}</span>
          </>
        )}
      </button>

      {notice && (
        <p className="text-sm text-amber-900 bg-amber-50 border border-amber-200 rounded-xl px-3 py-2 flex items-start gap-2">
          <Info className="w-4 h-4 shrink-0 mt-0.5 text-amber-700" aria-hidden="true" />
          <span>{notice}</span>
        </p>
      )}
    </div>
  );
}
