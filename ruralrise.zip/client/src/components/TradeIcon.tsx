import {
  Flame,
  HeartPulse,
  Landmark,
  Sprout,
  Store,
  Sun,
  Tractor,
  Wrench,
  Zap,
} from 'lucide-react';
import type { TradeCategoryId } from '../types/index.ts';

interface TradeIconProps {
  tradeId: TradeCategoryId;
  className?: string;
}

export function TradeIcon({ tradeId, className = 'w-6 h-6' }: TradeIconProps) {
  switch (tradeId) {
    case 'solar':
      return <Sun className={className} aria-hidden="true" />;
    case 'electrical':
      return <Zap className={className} aria-hidden="true" />;
    case 'mechanical':
      return <Wrench className={className} aria-hidden="true" />;
    case 'agritech':
      return <Sprout className={className} aria-hidden="true" />;
    case 'welding':
      return <Flame className={className} aria-hidden="true" />;
    case 'agriculture':
      return <Tractor className={className} aria-hidden="true" />;
    case 'retail':
      return <Store className={className} aria-hidden="true" />;
    case 'healthcare':
      return <HeartPulse className={className} aria-hidden="true" />;
    case 'banking':
      return <Landmark className={className} aria-hidden="true" />;
  }
}
