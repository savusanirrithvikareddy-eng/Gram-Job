import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import type {
  ApplicationStatus,
  CandidateProfile,
  JobApplication,
  JobVacancy,
  JobWithMatch,
} from '../types/index.ts';
import {
  createJobApi,
  fetchApplicationsApi,
  fetchJobs,
  getStoredCandidate,
  saveCandidateApi,
  storeCandidateLocally,
  submitApplicationApi,
  updateApplicationStatusApi,
} from '../utils/apiClient.ts';
import { useLanguage } from './LanguageContext.tsx';

export type NavTab = 'jobs' | 'skills' | 'applications' | 'post';

export interface JobFilters {
  search: string;
  trade: string;
  district: string;
  minSalary: number;
  accommodationOnly: boolean;
  sort: 'match' | 'salary' | 'distance';
}

interface ToastState {
  id: number;
  message: string;
  tone: 'success' | 'info' | 'error';
}

interface AppStateContextValue {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  candidate: CandidateProfile;
  jobs: JobWithMatch[];
  loadingJobs: boolean;
  isOffline: boolean;
  filters: JobFilters;
  setFilters: React.Dispatch<React.SetStateAction<JobFilters>>;
  resetFilters: () => void;
  selectedJob: JobWithMatch | null;
  setSelectedJob: (job: JobWithMatch | null) => void;
  applyModalJob: JobWithMatch | null;
  setApplyModalJob: (job: JobWithMatch | null) => void;
  applications: JobApplication[];
  appliedJobIds: Set<string>;
  showSkillPrompt: boolean;
  dismissSkillPrompt: () => void;
  toast: ToastState | null;
  showToast: (message: string, tone?: ToastState['tone']) => void;
  saveProfile: (nextProfile: CandidateProfile) => Promise<void>;
  loadDemoItiProfile: () => Promise<void>;
  applyToJob: (job: JobWithMatch, phone: string, availabilityDate: string) => Promise<void>;
  advanceApplicationStatus: (appId: string) => Promise<void>;
  postNewJob: (input: Omit<JobVacancy, 'id' | 'postedDate'>) => Promise<JobVacancy>;
  refreshJobs: () => Promise<void>;
}

const DEFAULT_FILTERS: JobFilters = {
  search: '',
  trade: 'all',
  district: 'all',
  minSalary: 0,
  accommodationOnly: false,
  sort: 'match',
};

function createEmptyCandidate(): CandidateProfile {
  return {
    id: `cand-${Math.random().toString(36).slice(2, 10)}`,
    name: '',
    phone: '',
    phoneVerified: false,
    district: 'Jaipur',
    state: 'Rajasthan',
    skills: [],
    updatedAt: new Date().toISOString(),
  };
}

const STATUS_PROGRESSION: Record<ApplicationStatus, ApplicationStatus> = {
  Applied: 'Under Review',
  'Under Review': 'Interview Call',
  'Interview Call': 'Selected',
  Selected: 'Not Selected',
  'Not Selected': 'Applied',
};

const AppStateContext = createContext<AppStateContextValue | null>(null);

export function AppStateProvider({ children }: { children: React.ReactNode }) {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState<NavTab>('jobs');
  const [candidate, setCandidate] = useState<CandidateProfile>(() => {
    const saved = getStoredCandidate();
    if (saved) return saved;
    const empty = createEmptyCandidate();
    storeCandidateLocally(empty);
    return empty;
  });
  const [jobs, setJobs] = useState<JobWithMatch[]>([]);
  const [loadingJobs, setLoadingJobs] = useState<boolean>(true);
  const [isOffline, setIsOffline] = useState<boolean>(false);
  const [filters, setFilters] = useState<JobFilters>(DEFAULT_FILTERS);
  const [selectedJob, setSelectedJob] = useState<JobWithMatch | null>(null);
  const [applyModalJob, setApplyModalJob] = useState<JobWithMatch | null>(null);
  const [applications, setApplications] = useState<JobApplication[]>([]);
  const [promptDismissed, setPromptDismissed] = useState<boolean>(false);
  const [toast, setToast] = useState<ToastState | null>(null);

  const showToast = useCallback((message: string, tone: ToastState['tone'] = 'success') => {
    const id = Date.now();
    setToast({ id, message, tone });
    window.setTimeout(() => {
      setToast((current) => (current?.id === id ? null : current));
    }, 4000);
  }, []);

  const refreshJobs = useCallback(async () => {
    setLoadingJobs(true);
    const result = await fetchJobs({
      candidateId: candidate.skills.length > 0 || candidate.name ? candidate.id : undefined,
      candidate,
      search: filters.search,
      trade: filters.trade,
      district: filters.district,
      minSalary: filters.minSalary,
      accommodationOnly: filters.accommodationOnly,
      sort: filters.sort,
    });
    setJobs(result.jobs);
    setIsOffline(result.offline);
    setLoadingJobs(false);

    if (selectedJob) {
      const updatedSelected = result.jobs.find((j) => j.id === selectedJob.id);
      if (updatedSelected) setSelectedJob(updatedSelected);
    }
  }, [candidate, filters, selectedJob]);

  useEffect(() => {
    void refreshJobs();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [candidate, filters]);

  useEffect(() => {
    let active = true;
    fetchApplicationsApi(candidate.id).then((res) => {
      if (active) setApplications(res.applications);
    });
    return () => {
      active = false;
    };
  }, [candidate.id]);

  // Sync candidate to backend once on startup if skills/name already exist in LocalStorage
  useEffect(() => {
    if (candidate.name && candidate.phone && candidate.skills.length > 0) {
      void saveCandidateApi(candidate);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const saveProfile = async (nextProfile: CandidateProfile) => {
    const { profile, offline } = await saveCandidateApi(nextProfile);
    setCandidate(profile);
    setIsOffline(offline);
    showToast(t.profileSavedToast, 'success');
  };

  const loadDemoItiProfile = async () => {
    const demoProfile: CandidateProfile = {
      id: candidate.id || 'cand-demo-iti',
      name: 'रमेश कुमार / Ramesh Kumar',
      phone: '9829012345',
      phoneVerified: true,
      district: 'Jaipur',
      state: 'Rajasthan',
      skills: [
        {
          skillId: 'solar_pv_installation',
          tradeId: 'solar',
          years: 1,
          certified: true,
          certificateType: 'ITI',
        },
        {
          skillId: 'electrical_wiring',
          tradeId: 'electrical',
          years: 1,
          certified: true,
          certificateType: 'ITI',
        },
      ],
      updatedAt: new Date().toISOString(),
    };
    const { profile, offline } = await saveCandidateApi(demoProfile);
    setCandidate(profile);
    setIsOffline(offline);
    setPromptDismissed(true);
    setFilters((prev) => ({ ...prev, sort: 'match' }));
    showToast(t.demoLoadedToast, 'success');
  };

  const applyToJob = async (job: JobWithMatch, phone: string, availabilityDate: string) => {
    const { application, offline } = await submitApplicationApi({
      job,
      candidateId: candidate.id,
      phone,
      availabilityDate,
    });
    setIsOffline(offline);
    setApplications((prev) => [application, ...prev.filter((a) => a.jobId !== job.id)]);
    setApplyModalJob(null);
    showToast(`${t.applySuccessTitle} ${t.applySuccessBody}`, 'success');
  };

  const advanceApplicationStatus = async (appId: string) => {
    const current = applications.find((a) => a.id === appId);
    if (!current) return;
    const nextStatus = STATUS_PROGRESSION[current.status] ?? 'Under Review';
    const { application, offline } = await updateApplicationStatusApi(appId, nextStatus);
    setIsOffline(offline);
    if (application) {
      setApplications((prev) => prev.map((a) => (a.id === appId ? application : a)));
    }
  };

  const postNewJob = async (input: Omit<JobVacancy, 'id' | 'postedDate'>): Promise<JobVacancy> => {
    const { job, offline } = await createJobApi(input);
    setIsOffline(offline);
    await refreshJobs();
    setActiveTab('jobs');
    showToast(t.jobPostedToast, 'success');
    return job;
  };

  const resetFilters = () => setFilters(DEFAULT_FILTERS);
  const appliedJobIds = new Set(applications.map((a) => a.jobId));
  const showSkillPrompt = !promptDismissed && candidate.skills.length === 0;

  return (
    <AppStateContext.Provider
      value={{
        activeTab,
        setActiveTab,
        candidate,
        jobs,
        loadingJobs,
        isOffline,
        filters,
        setFilters,
        resetFilters,
        selectedJob,
        setSelectedJob,
        applyModalJob,
        setApplyModalJob,
        applications,
        appliedJobIds,
        showSkillPrompt,
        dismissSkillPrompt: () => setPromptDismissed(true),
        toast,
        showToast,
        saveProfile,
        loadDemoItiProfile,
        applyToJob,
        advanceApplicationStatus,
        postNewJob,
        refreshJobs,
      }}
    >
      {children}
    </AppStateContext.Provider>
  );
}

export function useAppState(): AppStateContextValue {
  const ctx = useContext(AppStateContext);
  if (!ctx) throw new Error('useAppState must be used within AppStateProvider');
  return ctx;
}
