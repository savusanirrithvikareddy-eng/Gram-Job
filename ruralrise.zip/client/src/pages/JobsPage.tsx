import { Award, BedDouble, Search, SlidersHorizontal, Sparkles, X } from 'lucide-react';
import { JobCard } from '../components/JobCard.tsx';
import { useAppState } from '../context/AppStateContext.tsx';
import { useLanguage } from '../context/LanguageContext.tsx';
import { DISTRICTS, getDistrictLabel } from '../data/districts.ts';
import { TRADE_CATEGORIES } from '../data/taxonomy.ts';

export function JobsPage() {
  const { lang, t } = useLanguage();
  const {
    jobs,
    loadingJobs,
    filters,
    setFilters,
    resetFilters,
    showSkillPrompt,
    dismissSkillPrompt,
    loadDemoItiProfile,
    setActiveTab,
    candidate,
  } = useAppState();

  const hasActiveFilters =
    filters.search.trim() !== '' ||
    filters.trade !== 'all' ||
    filters.district !== 'all' ||
    filters.minSalary > 0 ||
    filters.accommodationOnly;

  return (
    <div className="space-y-6">
      {showSkillPrompt && (
        <section
          aria-label={t.demoPromptTitle}
          className="bg-green-950 text-white rounded-2xl p-5 sm:p-6 shadow-sm space-y-4"
        >
          <div className="flex items-start justify-between gap-3">
            <div className="space-y-1.5">
              <h1 className="text-xl sm:text-2xl font-bold leading-snug">{t.demoPromptTitle}</h1>
              <p className="text-sm sm:text-base text-green-100">{t.demoPromptBody}</p>
            </div>
            <button
              type="button"
              onClick={dismissSkillPrompt}
              aria-label={t.dismiss}
              className="min-w-[44px] min-h-[44px] rounded-xl text-green-200 hover:bg-green-900 flex items-center justify-center shrink-0"
            >
              <X className="w-5 h-5" aria-hidden="true" />
            </button>
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            <button
              type="button"
              onClick={() => void loadDemoItiProfile()}
              className="min-h-[48px] px-5 py-3 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-base flex items-center justify-center gap-2 transition-colors"
            >
              <Sparkles className="w-5 h-5" aria-hidden="true" />
              <span>{t.loadDemoProfile}</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('skills')}
              className="min-h-[48px] px-5 py-3 rounded-xl bg-green-800 hover:bg-green-700 text-white font-semibold text-base flex items-center justify-center gap-2 transition-colors"
            >
              <Award className="w-5 h-5" aria-hidden="true" />
              <span>{t.buildMySkills}</span>
            </button>
          </div>
        </section>
      )}

      {/* Search & Filter Panel */}
      <section
        aria-label={t.navJobs}
        className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 space-y-4 shadow-sm"
      >
        <div className="flex flex-col md:flex-row gap-3">
          <div className="relative flex-1">
            <Search
              className="w-5 h-5 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
              aria-hidden="true"
            />
            <input
              type="search"
              aria-label={t.searchPlaceholder}
              value={filters.search}
              onChange={(e) => setFilters((prev) => ({ ...prev, search: e.target.value }))}
              placeholder={t.searchPlaceholder}
              className="w-full min-h-[48px] pl-11 pr-4 rounded-xl border border-slate-300 bg-slate-50 focus:bg-white text-base text-slate-950"
            />
          </div>

          <div className="flex items-center gap-2">
            <SlidersHorizontal className="w-5 h-5 text-green-900 shrink-0" aria-hidden="true" />
            <select
              aria-label={t.sortBy}
              value={filters.sort}
              onChange={(e) =>
                setFilters((prev) => ({
                  ...prev,
                  sort: e.target.value as 'match' | 'salary' | 'distance',
                }))
              }
              className="w-full md:w-auto min-h-[48px] px-3.5 rounded-xl border border-slate-300 bg-white text-sm sm:text-base font-medium text-slate-900"
            >
              <option value="match">{t.sortBestMatch}</option>
              <option value="salary">{t.sortHighestSalary}</option>
              <option value="distance">{t.sortNearest}</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <select
            aria-label={t.filterTrade}
            value={filters.trade}
            onChange={(e) => setFilters((prev) => ({ ...prev, trade: e.target.value }))}
            className="min-h-[48px] px-3.5 rounded-xl border border-slate-300 bg-white text-sm sm:text-base text-slate-900"
          >
            <option value="all">{t.filterAllTrades}</option>
            {TRADE_CATEGORIES.map((trade) => (
              <option key={trade.id} value={trade.id}>
                {lang === 'hi' ? trade.nameHi : trade.nameEn}
              </option>
            ))}
          </select>

          <select
            aria-label={t.filterDistrict}
            value={filters.district}
            onChange={(e) => setFilters((prev) => ({ ...prev, district: e.target.value }))}
            className="min-h-[48px] px-3.5 rounded-xl border border-slate-300 bg-white text-sm sm:text-base text-slate-900"
          >
            <option value="all">{t.filterAllDistricts}</option>
            {DISTRICTS.map((d) => (
              <option key={d.district} value={d.district}>
                {getDistrictLabel(d.district, lang)}
              </option>
            ))}
          </select>

          <select
            aria-label={t.filterMinSalary}
            value={filters.minSalary}
            onChange={(e) => setFilters((prev) => ({ ...prev, minSalary: Number(e.target.value) }))}
            className="min-h-[48px] px-3.5 rounded-xl border border-slate-300 bg-white text-sm sm:text-base text-slate-900"
          >
            <option value={0}>{t.filterAnySalary}</option>
            <option value={12000}>₹12,000+</option>
            <option value={15000}>₹15,000+</option>
            <option value={18000}>₹18,000+</option>
            <option value={20000}>₹20,000+</option>
          </select>

          <button
            type="button"
            onClick={() =>
              setFilters((prev) => ({ ...prev, accommodationOnly: !prev.accommodationOnly }))
            }
            aria-pressed={filters.accommodationOnly}
            className={`min-h-[48px] px-3.5 rounded-xl border text-sm sm:text-base font-semibold flex items-center justify-center gap-2 transition-colors ${
              filters.accommodationOnly
                ? 'bg-green-900 text-white border-green-900'
                : 'bg-white text-slate-800 border-slate-300 hover:bg-slate-50'
            }`}
          >
            <BedDouble className="w-5 h-5" aria-hidden="true" />
            <span>{t.filterRoomOnly}</span>
          </button>
        </div>
      </section>

      {/* Result Summary Bar */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <p className="text-base font-semibold text-slate-800">
          <span className="font-mono-nums font-bold text-green-950">{jobs.length}</span>{' '}
          {t.jobsFound}
          {candidate.skills.length === 0 && (
            <button
              type="button"
              onClick={() => setActiveTab('skills')}
              className="ml-3 text-sm font-semibold text-amber-800 underline hover:text-amber-950"
            >
              {t.selectSkillsPrompt}
            </button>
          )}
        </p>

        {hasActiveFilters && (
          <button
            type="button"
            onClick={resetFilters}
            className="min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-300 bg-white text-sm font-semibold text-slate-800 hover:bg-slate-100"
          >
            {t.clearFilters}
          </button>
        )}
      </div>

      {/* Job Feed */}
      {loadingJobs ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {[1, 2, 3, 4, 5, 6].map((n) => (
            <div
              key={n}
              className="h-64 bg-white rounded-2xl border border-slate-200 p-5 animate-pulse"
            />
          ))}
        </div>
      ) : jobs.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center space-y-4">
          <p className="text-lg font-semibold text-slate-800">{t.noJobsMatch}</p>
          <button
            type="button"
            onClick={resetFilters}
            className="min-h-[48px] px-5 py-2.5 rounded-xl bg-green-900 text-white font-semibold"
          >
            {t.clearFilters}
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {jobs.map((job) => (
            <JobCard key={job.id} job={job} />
          ))}
        </div>
      )}
    </div>
  );
}
