import {
  Award,
  Check,
  CheckCircle2,
  Minus,
  Plus,
  ShieldCheck,
  Sparkles,
  Trash2,
} from 'lucide-react';
import React, { useEffect, useState } from 'react';
import { TradeIcon } from '../components/TradeIcon.tsx';
import { useAppState } from '../context/AppStateContext.tsx';
import { useLanguage } from '../context/LanguageContext.tsx';
import { DISTRICTS, getDistrictLabel, getStateLabel } from '../data/districts.ts';
import {
  getSkillLabel,
  getTradeLabel,
  TRADE_CATEGORIES,
  VOCATIONAL_SKILLS,
} from '../data/taxonomy.ts';
import type {
  CandidateProfile,
  CandidateSkill,
  CertificateType,
  TradeCategoryId,
} from '../types/index.ts';

const PHONE_REGEX = /^[6-9]\d{9}$/;

export function SkillsPage() {
  const { lang, t } = useLanguage();
  const { candidate, saveProfile, loadDemoItiProfile, setActiveTab } = useAppState();

  const [name, setName] = useState(candidate.name);
  const [phone, setPhone] = useState(candidate.phone);
  const [phoneVerified, setPhoneVerified] = useState(candidate.phoneVerified);
  const [otpSent, setOtpSent] = useState(false);
  const [otpValue, setOtpValue] = useState('');
  const [otpError, setOtpError] = useState<string | null>(null);
  const [district, setDistrict] = useState(candidate.district || 'Jaipur');
  const [stateName, setStateName] = useState(candidate.state || 'Rajasthan');
  const [skills, setSkills] = useState<CandidateSkill[]>(candidate.skills);
  const [expandedTrade, setExpandedTrade] = useState<TradeCategoryId>('solar');
  const [formError, setFormError] = useState<string | null>(null);

  useEffect(() => {
    setName(candidate.name);
    setPhone(candidate.phone);
    setPhoneVerified(candidate.phoneVerified);
    setDistrict(candidate.district || 'Jaipur');
    setStateName(candidate.state || 'Rajasthan');
    setSkills(candidate.skills);
  }, [candidate]);

  const handleDistrictChange = (nextDistrict: string) => {
    setDistrict(nextDistrict);
    const info = DISTRICTS.find((d) => d.district === nextDistrict);
    if (info) setStateName(info.state);
  };

  const handleSendOtp = () => {
    const cleaned = phone.replace(/\D/g, '');
    if (!PHONE_REGEX.test(cleaned)) {
      setOtpError(t.invalidPhoneError);
      return;
    }
    setPhone(cleaned);
    setOtpError(null);
    setOtpSent(true);
    setOtpValue('');
  };

  const handleVerifyOtp = () => {
    if (otpValue.trim() === '1234') {
      setPhoneVerified(true);
      setOtpSent(false);
      setOtpError(null);
    } else {
      setOtpError(t.invalidOtpError);
    }
  };

  const toggleSkill = (skillId: string, tradeId: TradeCategoryId) => {
    setSkills((prev) => {
      const exists = prev.some((s) => s.skillId === skillId);
      if (exists) {
        return prev.filter((s) => s.skillId !== skillId);
      }
      return [
        ...prev,
        {
          skillId,
          tradeId,
          years: 1,
          certified: false,
          certificateType: 'ITI',
        },
      ];
    });
  };

  const updateSkill = (skillId: string, patch: Partial<CandidateSkill>) => {
    setSkills((prev) => prev.map((s) => (s.skillId === skillId ? { ...s, ...patch } : s)));
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanedPhone = phone.replace(/\D/g, '');
    if (!name.trim()) {
      setFormError(t.nameRequiredError);
      return;
    }
    if (!PHONE_REGEX.test(cleanedPhone)) {
      setFormError(t.invalidPhoneError);
      return;
    }

    setFormError(null);
    const updated: CandidateProfile = {
      ...candidate,
      name: name.trim(),
      phone: cleanedPhone,
      phoneVerified,
      district,
      state: stateName,
      skills,
      updatedAt: new Date().toISOString(),
    };
    await saveProfile(updated);
    setActiveTab('jobs');
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-950">{t.skillsPageTitle}</h1>
          <p className="text-base text-slate-700">{t.skillsPageSubtitle}</p>
        </div>

        <button
          type="button"
          onClick={() => void loadDemoItiProfile()}
          className="min-h-[48px] px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-sm sm:text-base flex items-center justify-center gap-2 shrink-0 transition-colors"
        >
          <Sparkles className="w-5 h-5" aria-hidden="true" />
          <span>{t.loadDemoProfile}</span>
        </button>
      </div>

      {/* Verified Skill Badges Strip */}
      {skills.some((s) => s.certified) && (
        <section
          aria-label={t.verifiedSkillBadge}
          className="bg-emerald-950 text-white rounded-2xl p-4 sm:p-5 space-y-2.5"
        >
          <div className="flex items-center gap-2 font-bold text-base">
            <ShieldCheck className="w-5 h-5 text-amber-400" aria-hidden="true" />
            <span>{t.verifiedSkillBadge}</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {skills
              .filter((s) => s.certified)
              .map((s) => (
                <span
                  key={s.skillId}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-800 border border-emerald-600 text-sm font-semibold"
                >
                  <Award className="w-4 h-4 text-amber-300" aria-hidden="true" />
                  <span>
                    {getSkillLabel(s.skillId, lang)} ({s.certificateType})
                  </span>
                </span>
              ))}
          </div>
        </section>
      )}

      <form onSubmit={handleSave} className="space-y-6">
        {/* Trade Cards Picker */}
        <fieldset className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 space-y-4 shadow-sm">
          <legend className="text-lg font-bold text-slate-950 px-1">{t.tradePickerTitle}</legend>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            {TRADE_CATEGORIES.map((trade) => {
              const isOpen = expandedTrade === trade.id;
              const selectedCount = skills.filter((s) => s.tradeId === trade.id).length;
              return (
                <button
                  key={trade.id}
                  type="button"
                  onClick={() => setExpandedTrade(trade.id)}
                  aria-expanded={isOpen}
                  className={`min-h-[84px] p-3 rounded-2xl border-2 text-left flex flex-col justify-between gap-2 transition-colors ${
                    isOpen
                      ? 'border-green-900 bg-green-50 text-green-950'
                      : 'border-slate-200 bg-white hover:border-green-700 text-slate-900'
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    <span
                      className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                        isOpen ? 'bg-green-900 text-white' : 'bg-slate-100 text-green-900'
                      }`}
                    >
                      <TradeIcon tradeId={trade.id} className="w-5 h-5" />
                    </span>
                    {selectedCount > 0 && (
                      <span className="font-mono-nums px-2 py-0.5 rounded-lg bg-amber-600 text-white text-xs font-bold">
                        {selectedCount}
                      </span>
                    )}
                  </div>
                  <span className="font-bold text-sm leading-tight">
                    {lang === 'hi' ? trade.nameHi : trade.nameEn}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Skills inside selected trade */}
          <div className="pt-3 border-t border-slate-200 space-y-3">
            <p className="text-sm font-semibold text-green-950">
              {getTradeLabel(expandedTrade, lang)}
            </p>
            <div className="flex flex-wrap gap-2.5">
              {VOCATIONAL_SKILLS.filter((s) => s.tradeId === expandedTrade).map((skill) => {
                const selected = skills.some((item) => item.skillId === skill.id);
                return (
                  <button
                    key={skill.id}
                    type="button"
                    onClick={() => toggleSkill(skill.id, skill.tradeId)}
                    aria-pressed={selected}
                    className={`min-h-[48px] px-4 py-2.5 rounded-xl border-2 font-semibold text-sm sm:text-base flex items-center gap-2 transition-colors ${
                      selected
                        ? 'bg-green-900 text-white border-green-900'
                        : 'bg-white text-slate-900 border-slate-300 hover:border-green-700'
                    }`}
                  >
                    {selected && <Check className="w-4 h-4 shrink-0" aria-hidden="true" />}
                    <span>{lang === 'hi' ? skill.nameHi : skill.nameEn}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </fieldset>

        {/* Selected Skills Configurator */}
        <fieldset className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 space-y-4 shadow-sm">
          <legend className="text-lg font-bold text-slate-950 px-1">
            {t.selectedSkillsTitle} ({skills.length})
          </legend>

          {skills.length === 0 ? (
            <p className="text-base text-slate-600 py-3">{t.noSkillsSelected}</p>
          ) : (
            <div className="space-y-4">
              {skills.map((item) => (
                <div
                  key={item.skillId}
                  className="rounded-2xl border border-slate-200 bg-slate-50 p-4 space-y-4"
                >
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2.5">
                      <span className="w-9 h-9 rounded-xl bg-green-900 text-white flex items-center justify-center shrink-0">
                        <TradeIcon tradeId={item.tradeId} className="w-5 h-5" />
                      </span>
                      <div>
                        <h3 className="font-bold text-base text-slate-950">
                          {getSkillLabel(item.skillId, lang)}
                        </h3>
                        <p className="text-xs text-slate-600">{getTradeLabel(item.tradeId, lang)}</p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => toggleSkill(item.skillId, item.tradeId)}
                      aria-label={`Remove ${getSkillLabel(item.skillId, lang)}`}
                      className="min-w-[44px] min-h-[44px] rounded-xl border border-slate-300 bg-white text-red-700 hover:bg-red-50 flex items-center justify-center"
                    >
                      <Trash2 className="w-5 h-5" aria-hidden="true" />
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Years Stepper (zero typing) */}
                    <div className="space-y-1.5">
                      <span className="block text-sm font-semibold text-slate-800">
                        {t.experienceYearsLabel}
                      </span>
                      <div className="flex items-center gap-3">
                        <button
                          type="button"
                          onClick={() =>
                            updateSkill(item.skillId, { years: Math.max(0, item.years - 1) })
                          }
                          aria-label="Decrease years"
                          className="min-w-[48px] min-h-[48px] rounded-xl border border-slate-300 bg-white hover:bg-slate-100 flex items-center justify-center text-slate-900"
                        >
                          <Minus className="w-5 h-5" aria-hidden="true" />
                        </button>
                        <span className="font-mono-nums text-lg font-bold text-slate-950 min-w-[70px] text-center">
                          {item.years} {t.yearsUnit}
                        </span>
                        <button
                          type="button"
                          onClick={() =>
                            updateSkill(item.skillId, { years: Math.min(20, item.years + 1) })
                          }
                          aria-label="Increase years"
                          className="min-w-[48px] min-h-[48px] rounded-xl border border-slate-300 bg-white hover:bg-slate-100 flex items-center justify-center text-slate-900"
                        >
                          <Plus className="w-5 h-5" aria-hidden="true" />
                        </button>
                      </div>
                    </div>

                    {/* ITI / PMKVY Certificate */}
                    <div className="space-y-2">
                      <span className="block text-sm font-semibold text-slate-800">
                        {t.certificateQuestion}
                      </span>
                      <div className="flex flex-wrap items-center gap-2">
                        <button
                          type="button"
                          onClick={() => updateSkill(item.skillId, { certified: true })}
                          className={`min-h-[48px] px-4 rounded-xl border font-semibold text-sm transition-colors ${
                            item.certified
                              ? 'bg-green-900 text-white border-green-900'
                              : 'bg-white text-slate-800 border-slate-300'
                          }`}
                        >
                          {t.yesLabel}
                        </button>
                        <button
                          type="button"
                          onClick={() => updateSkill(item.skillId, { certified: false })}
                          className={`min-h-[48px] px-4 rounded-xl border font-semibold text-sm transition-colors ${
                            !item.certified
                              ? 'bg-slate-800 text-white border-slate-800'
                              : 'bg-white text-slate-800 border-slate-300'
                          }`}
                        >
                          {t.noLabel}
                        </button>

                        {item.certified && (
                          <select
                            aria-label={t.certTypeLabel}
                            value={item.certificateType}
                            onChange={(e) =>
                              updateSkill(item.skillId, {
                                certificateType: e.target.value as CertificateType,
                              })
                            }
                            className="min-h-[48px] px-3 rounded-xl border border-green-700 bg-white text-sm font-bold text-green-950"
                          >
                            <option value="ITI">ITI</option>
                            <option value="PMKVY">PMKVY</option>
                            <option value="Diploma">Diploma</option>
                          </select>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </fieldset>

        {/* Personal Details & Simulated OTP Verification */}
        <fieldset className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 space-y-4 shadow-sm">
          <legend className="text-lg font-bold text-slate-950 px-1">
            {t.personalInfoSection}
          </legend>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="cand-name" className="block text-sm font-bold text-slate-900 mb-1.5">
                {t.fullNameLabel}
              </label>
              <input
                id="cand-name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder={t.fullNamePlaceholder}
                className="w-full min-h-[48px] px-4 rounded-xl border border-slate-300 bg-white text-base text-slate-950"
                required
              />
            </div>

            <div>
              <label
                htmlFor="cand-district"
                className="block text-sm font-bold text-slate-900 mb-1.5"
              >
                {t.homeDistrictLabel}
              </label>
              <select
                id="cand-district"
                value={district}
                onChange={(e) => handleDistrictChange(e.target.value)}
                className="w-full min-h-[48px] px-3.5 rounded-xl border border-slate-300 bg-white text-base text-slate-950"
              >
                {DISTRICTS.map((d) => (
                  <option key={d.district} value={d.district}>
                    {getDistrictLabel(d.district, lang)} ({getStateLabel(d.state, lang)})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <label htmlFor="cand-phone" className="text-sm font-bold text-slate-900">
                {t.phoneLabel}
              </label>
              <span
                className={`text-xs font-bold px-2.5 py-1 rounded-lg inline-flex items-center gap-1 ${
                  phoneVerified
                    ? 'bg-emerald-100 text-emerald-900'
                    : 'bg-amber-100 text-amber-900'
                }`}
              >
                {phoneVerified && <CheckCircle2 className="w-3.5 h-3.5" aria-hidden="true" />}
                <span>{phoneVerified ? t.phoneVerifiedBadge : t.phoneNotVerifiedBadge}</span>
              </span>
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <input
                id="cand-phone"
                type="tel"
                inputMode="numeric"
                maxLength={10}
                value={phone}
                onChange={(e) => {
                  setPhone(e.target.value.replace(/\D/g, '').slice(0, 10));
                  setPhoneVerified(false);
                }}
                placeholder={t.phonePlaceholder}
                className="font-mono-nums flex-1 min-h-[48px] px-4 rounded-xl border border-slate-300 bg-white text-base text-slate-950"
                required
              />
              {!phoneVerified && (
                <button
                  type="button"
                  onClick={handleSendOtp}
                  className="min-h-[48px] px-5 py-2.5 rounded-xl bg-green-900 hover:bg-green-800 text-white font-semibold text-sm sm:text-base shrink-0"
                >
                  {t.verifyOtpBtn}
                </button>
              )}
            </div>

            {otpSent && !phoneVerified && (
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-3.5 space-y-2.5">
                <p className="text-sm font-semibold text-amber-950">{t.otpSentHint}</p>
                <div className="flex flex-col sm:flex-row gap-2.5">
                  <input
                    type="text"
                    inputMode="numeric"
                    maxLength={4}
                    aria-label={t.otpInputLabel}
                    value={otpValue}
                    onChange={(e) => setOtpValue(e.target.value.replace(/\D/g, '').slice(0, 4))}
                    placeholder="1234"
                    className="font-mono-nums min-h-[48px] px-4 rounded-xl border border-amber-300 bg-white text-lg text-slate-950 w-full sm:w-40"
                  />
                  <button
                    type="button"
                    onClick={handleVerifyOtp}
                    className="min-h-[48px] px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-sm sm:text-base"
                  >
                    {t.confirmOtpBtn}
                  </button>
                </div>
              </div>
            )}

            {otpError && <p className="text-sm font-semibold text-red-700">{otpError}</p>}
          </div>
        </fieldset>

        {formError && (
          <p role="alert" className="text-sm font-bold text-red-800 bg-red-50 border border-red-300 rounded-xl p-3">
            {formError}
          </p>
        )}

        <button
          type="submit"
          className="w-full min-h-[54px] px-6 py-3.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-lg shadow-sm transition-colors"
        >
          {t.saveProfileBtn}
        </button>
      </form>
    </div>
  );
}
