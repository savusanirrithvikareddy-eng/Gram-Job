import { Check, Minus, Plus, Send } from 'lucide-react';
import React, { useState } from 'react';
import { useAppState } from '../context/AppStateContext.tsx';
import { useLanguage } from '../context/LanguageContext.tsx';
import { DISTRICTS, getDistrictLabel, getStateLabel } from '../data/districts.ts';
import { TRADE_CATEGORIES, VOCATIONAL_SKILLS } from '../data/taxonomy.ts';
import { EMPLOYER_TYPE_LABELS } from '../i18n/translations.ts';
import type { EmployerType, TradeCategoryId } from '../types/index.ts';

const PHONE_REGEX = /^[6-9]\d{9}$/;

export function PostJobPage() {
  const { lang, t } = useLanguage();
  const { postNewJob } = useAppState();

  const [titleEn, setTitleEn] = useState('');
  const [titleHi, setTitleHi] = useState('');
  const [employerName, setEmployerName] = useState('');
  const [employerType, setEmployerType] = useState<EmployerType>('rural_enterprise');
  const [tradeCategory, setTradeCategory] = useState<TradeCategoryId>('solar');
  const [district, setDistrict] = useState('Jaipur');
  const [stateName, setStateName] = useState('Rajasthan');
  const [monthlySalary, setMonthlySalary] = useState('18000');
  const [minExperienceYears, setMinExperienceYears] = useState(1);
  const [foodProvided, setFoodProvided] = useState(false);
  const [accommodationProvided, setAccommodationProvided] = useState(true);
  const [certificationPreferred, setCertificationPreferred] = useState(true);
  const [whatsappNumber, setWhatsappNumber] = useState('');
  const [requiredSkills, setRequiredSkills] = useState<string[]>(['solar_pv_installation']);
  const [optionalSkills, setOptionalSkills] = useState<string[]>([]);
  const [responsibilitiesText, setResponsibilitiesText] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleDistrictChange = (nextDistrict: string) => {
    setDistrict(nextDistrict);
    const info = DISTRICTS.find((d) => d.district === nextDistrict);
    if (info) setStateName(info.state);
  };

  const toggleSkillSelection = (list: string[], setList: (next: string[]) => void, id: string) => {
    if (list.includes(id)) {
      setList(list.filter((s) => s !== id));
    } else {
      setList([...list, id]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanedPhone = whatsappNumber.replace(/\D/g, '');
    const salaryNum = Number(monthlySalary);

    if (
      !titleEn.trim() ||
      !employerName.trim() ||
      !PHONE_REGEX.test(cleanedPhone) ||
      !Number.isFinite(salaryNum) ||
      salaryNum < 3000 ||
      requiredSkills.length === 0
    ) {
      setError(t.formFixErrors);
      return;
    }

    const bullets = responsibilitiesText
      .split('\n')
      .map((line) => line.trim())
      .filter(Boolean);

    setError(null);
    setSubmitting(true);
    await postNewJob({
      titleEn: titleEn.trim(),
      titleHi: titleHi.trim() || titleEn.trim(),
      employerName: employerName.trim(),
      employerType,
      district,
      state: stateName,
      tradeCategory,
      requiredSkills,
      optionalSkills: optionalSkills.filter((id) => !requiredSkills.includes(id)),
      minExperienceYears,
      certificationPreferred,
      monthlySalary: Math.round(salaryNum),
      foodProvided,
      accommodationProvided,
      responsibilitiesEn:
        bullets.length > 0
          ? bullets
          : ['Execute field/workshop tasks safely and coordinate with local supervisor.'],
      responsibilitiesHi:
        bullets.length > 0
          ? bullets
          : ['निर्धारित ट्रेड कार्य सुरक्षित रूप से करना और सुपरवाइजर को रिपोर्ट करना।'],
      whatsappNumber: cleanedPhone,
    });
    setSubmitting(false);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div>
        <h1 className="text-2xl font-bold text-slate-950">{t.employerPageTitle}</h1>
        <p className="text-base text-slate-700">{t.employerPageSubtitle}</p>
      </div>

      <form
        onSubmit={handleSubmit}
        className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 space-y-5 shadow-sm"
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label htmlFor="post-title-en" className="block text-sm font-bold text-slate-900 mb-1.5">
              {t.jobTitleEnLabel} *
            </label>
            <input
              id="post-title-en"
              type="text"
              value={titleEn}
              onChange={(e) => setTitleEn(e.target.value)}
              placeholder="e.g. Solar Technician - Sikar"
              className="w-full min-h-[48px] px-4 rounded-xl border border-slate-300 bg-white text-base text-slate-950"
              required
            />
          </div>

          <div>
            <label htmlFor="post-title-hi" className="block text-sm font-bold text-slate-900 mb-1.5">
              {t.jobTitleHiLabel}
            </label>
            <input
              id="post-title-hi"
              type="text"
              value={titleHi}
              onChange={(e) => setTitleHi(e.target.value)}
              placeholder="जैसे: सोलर तकनीशियन - सीकर"
              className="w-full min-h-[48px] px-4 rounded-xl border border-slate-300 bg-white text-base text-slate-950"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label htmlFor="post-employer" className="block text-sm font-bold text-slate-900 mb-1.5">
              {t.employerNameLabel} *
            </label>
            <input
              id="post-employer"
              type="text"
              value={employerName}
              onChange={(e) => setEmployerName(e.target.value)}
              placeholder="e.g. Gramin Urja Enterprises"
              className="w-full min-h-[48px] px-4 rounded-xl border border-slate-300 bg-white text-base text-slate-950"
              required
            />
          </div>

          <div>
            <label htmlFor="post-emp-type" className="block text-sm font-bold text-slate-900 mb-1.5">
              {t.employerTypeLabel}
            </label>
            <select
              id="post-emp-type"
              value={employerType}
              onChange={(e) => setEmployerType(e.target.value as EmployerType)}
              className="w-full min-h-[48px] px-3.5 rounded-xl border border-slate-300 bg-white text-base text-slate-950"
            >
              {(Object.keys(EMPLOYER_TYPE_LABELS) as EmployerType[]).map((key) => (
                <option key={key} value={key}>
                  {EMPLOYER_TYPE_LABELS[key][lang]}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label htmlFor="post-trade" className="block text-sm font-bold text-slate-900 mb-1.5">
              {t.filterTrade}
            </label>
            <select
              id="post-trade"
              value={tradeCategory}
              onChange={(e) => setTradeCategory(e.target.value as TradeCategoryId)}
              className="w-full min-h-[48px] px-3.5 rounded-xl border border-slate-300 bg-white text-base text-slate-950"
            >
              {TRADE_CATEGORIES.map((tr) => (
                <option key={tr.id} value={tr.id}>
                  {lang === 'hi' ? tr.nameHi : tr.nameEn}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="post-district" className="block text-sm font-bold text-slate-900 mb-1.5">
              {t.filterDistrict}
            </label>
            <select
              id="post-district"
              value={district}
              onChange={(e) => handleDistrictChange(e.target.value)}
              className="w-full min-h-[48px] px-3.5 rounded-xl border border-slate-300 bg-white text-base text-slate-950"
            >
              {DISTRICTS.map((d) => (
                <option key={d.district} value={d.district}>
                  {getDistrictLabel(d.district, lang)} ({getStateLabel(d.state, lang)})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="post-salary" className="block text-sm font-bold text-slate-900 mb-1.5">
              {t.salaryLabel} *
            </label>
            <input
              id="post-salary"
              type="number"
              min={3000}
              max={200000}
              step={500}
              value={monthlySalary}
              onChange={(e) => setMonthlySalary(e.target.value)}
              className="font-mono-nums w-full min-h-[48px] px-4 rounded-xl border border-slate-300 bg-white text-base text-slate-950"
              required
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label htmlFor="post-whatsapp" className="block text-sm font-bold text-slate-900 mb-1.5">
              {t.whatsappLabel} *
            </label>
            <input
              id="post-whatsapp"
              type="tel"
              inputMode="numeric"
              maxLength={10}
              value={whatsappNumber}
              onChange={(e) => setWhatsappNumber(e.target.value.replace(/\D/g, '').slice(0, 10))}
              placeholder="9876543210"
              className="font-mono-nums w-full min-h-[48px] px-4 rounded-xl border border-slate-300 bg-white text-base text-slate-950"
              required
            />
          </div>

          <div>
            <span className="block text-sm font-bold text-slate-900 mb-1.5">
              {t.minExperienceLabel}
            </span>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setMinExperienceYears((y) => Math.max(0, y - 1))}
                aria-label="Decrease minimum experience"
                className="min-w-[48px] min-h-[48px] rounded-xl border border-slate-300 bg-white hover:bg-slate-50 flex items-center justify-center"
              >
                <Minus className="w-5 h-5" aria-hidden="true" />
              </button>
              <span className="font-mono-nums text-lg font-bold min-w-[70px] text-center">
                {minExperienceYears} {t.yearsUnit}
              </span>
              <button
                type="button"
                onClick={() => setMinExperienceYears((y) => Math.min(10, y + 1))}
                aria-label="Increase minimum experience"
                className="min-w-[48px] min-h-[48px] rounded-xl border border-slate-300 bg-white hover:bg-slate-50 flex items-center justify-center"
              >
                <Plus className="w-5 h-5" aria-hidden="true" />
              </button>
            </div>
          </div>
        </div>

        {/* Perks */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <button
            type="button"
            onClick={() => setAccommodationProvided((v) => !v)}
            aria-pressed={accommodationProvided}
            className={`min-h-[48px] px-4 py-2.5 rounded-xl border-2 font-semibold text-sm flex items-center justify-center gap-2 transition-colors ${
              accommodationProvided
                ? 'bg-green-900 text-white border-green-900'
                : 'bg-white text-slate-800 border-slate-300'
            }`}
          >
            {accommodationProvided && <Check className="w-4 h-4" aria-hidden="true" />}
            <span>{t.roomProvidedLabel}</span>
          </button>

          <button
            type="button"
            onClick={() => setFoodProvided((v) => !v)}
            aria-pressed={foodProvided}
            className={`min-h-[48px] px-4 py-2.5 rounded-xl border-2 font-semibold text-sm flex items-center justify-center gap-2 transition-colors ${
              foodProvided
                ? 'bg-green-900 text-white border-green-900'
                : 'bg-white text-slate-800 border-slate-300'
            }`}
          >
            {foodProvided && <Check className="w-4 h-4" aria-hidden="true" />}
            <span>{t.foodProvidedLabel}</span>
          </button>

          <button
            type="button"
            onClick={() => setCertificationPreferred((v) => !v)}
            aria-pressed={certificationPreferred}
            className={`min-h-[48px] px-4 py-2.5 rounded-xl border-2 font-semibold text-sm flex items-center justify-center gap-2 transition-colors ${
              certificationPreferred
                ? 'bg-amber-600 text-white border-amber-600'
                : 'bg-white text-slate-800 border-slate-300'
            }`}
          >
            {certificationPreferred && <Check className="w-4 h-4" aria-hidden="true" />}
            <span>{t.certPrefLabel}</span>
          </button>
        </div>

        {/* Required Skills */}
        <fieldset className="space-y-2.5 pt-2 border-t border-slate-200">
          <legend className="text-sm font-bold text-slate-900">{t.requiredSkillsLabel} *</legend>
          <div className="flex flex-wrap gap-2">
            {VOCATIONAL_SKILLS.map((skill) => {
              const selected = requiredSkills.includes(skill.id);
              return (
                <button
                  key={skill.id}
                  type="button"
                  onClick={() =>
                    toggleSkillSelection(requiredSkills, setRequiredSkills, skill.id)
                  }
                  aria-pressed={selected}
                  className={`min-h-[44px] px-3 py-2 rounded-xl border text-sm font-semibold flex items-center gap-1.5 transition-colors ${
                    selected
                      ? 'bg-green-900 text-white border-green-900'
                      : 'bg-slate-50 text-slate-800 border-slate-300 hover:bg-slate-100'
                  }`}
                >
                  {selected && <Check className="w-4 h-4" aria-hidden="true" />}
                  <span>{lang === 'hi' ? skill.nameHi : skill.nameEn}</span>
                </button>
              );
            })}
          </div>
        </fieldset>

        {/* Optional Skills */}
        <fieldset className="space-y-2.5 pt-2 border-t border-slate-200">
          <legend className="text-sm font-bold text-slate-900">{t.optionalSkillsLabel}</legend>
          <div className="flex flex-wrap gap-2">
            {VOCATIONAL_SKILLS.filter((s) => !requiredSkills.includes(s.id)).map((skill) => {
              const selected = optionalSkills.includes(skill.id);
              return (
                <button
                  key={skill.id}
                  type="button"
                  onClick={() =>
                    toggleSkillSelection(optionalSkills, setOptionalSkills, skill.id)
                  }
                  aria-pressed={selected}
                  className={`min-h-[44px] px-3 py-2 rounded-xl border text-sm font-semibold flex items-center gap-1.5 transition-colors ${
                    selected
                      ? 'bg-amber-600 text-white border-amber-600'
                      : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                  }`}
                >
                  {selected && <Check className="w-4 h-4" aria-hidden="true" />}
                  <span>{lang === 'hi' ? skill.nameHi : skill.nameEn}</span>
                </button>
              );
            })}
          </div>
        </fieldset>

        <div>
          <label
            htmlFor="post-responsibilities"
            className="block text-sm font-bold text-slate-900 mb-1.5"
          >
            {t.responsibilitiesInputLabel}
          </label>
          <textarea
            id="post-responsibilities"
            rows={3}
            value={responsibilitiesText}
            onChange={(e) => setResponsibilitiesText(e.target.value)}
            className="w-full p-3.5 rounded-xl border border-slate-300 bg-white text-base text-slate-950"
          />
        </div>

        {error && (
          <p role="alert" className="text-sm font-bold text-red-800 bg-red-50 border border-red-300 rounded-xl p-3">
            {error}
          </p>
        )}

        <button
          type="submit"
          disabled={submitting}
          className="w-full min-h-[54px] px-6 py-3.5 rounded-xl bg-amber-600 hover:bg-amber-700 disabled:opacity-60 text-white font-bold text-lg flex items-center justify-center gap-2 transition-colors"
        >
          <Send className="w-5 h-5" aria-hidden="true" />
          <span>{t.postJobBtn}</span>
        </button>
      </form>
    </div>
  );
}
