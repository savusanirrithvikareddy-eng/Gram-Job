import {
  ArrowRight,
  BedDouble,
  Briefcase,
  Calendar,
  CheckCircle2,
  Clock,
  MapPin,
  MessageCircle,
  PhoneCall,
  XCircle,
} from 'lucide-react';
import { useAppState } from '../context/AppStateContext.tsx';
import { useLanguage } from '../context/LanguageContext.tsx';
import { getDistrictLabel, getStateLabel } from '../data/districts.ts';
import { formatRupees, STATUS_LABELS } from '../i18n/translations.ts';
import type { ApplicationStatus } from '../types/index.ts';

function getStatusStyle(status: ApplicationStatus) {
  switch (status) {
    case 'Applied':
      return { bg: 'bg-slate-100 text-slate-900 border-slate-300', Icon: Clock };
    case 'Under Review':
      return { bg: 'bg-amber-100 text-amber-950 border-amber-300', Icon: Clock };
    case 'Interview Call':
      return { bg: 'bg-blue-100 text-blue-950 border-blue-300', Icon: PhoneCall };
    case 'Selected':
      return { bg: 'bg-emerald-100 text-emerald-950 border-emerald-300', Icon: CheckCircle2 };
    case 'Not Selected':
      return { bg: 'bg-red-100 text-red-950 border-red-300', Icon: XCircle };
  }
}

export function ApplicationsPage() {
  const { lang, t } = useLanguage();
  const { applications, advanceApplicationStatus, setActiveTab } = useAppState();

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div>
        <h1 className="text-2xl font-bold text-slate-950">{t.applicationsTitle}</h1>
        <p className="text-base text-slate-700">{t.applicationsSubtitle}</p>
      </div>

      {applications.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center space-y-4">
          <Briefcase className="w-10 h-10 text-green-800 mx-auto" aria-hidden="true" />
          <p className="text-lg font-semibold text-slate-800">{t.noApplicationsYet}</p>
          <button
            type="button"
            onClick={() => setActiveTab('jobs')}
            className="min-h-[48px] px-6 py-3 rounded-xl bg-green-900 hover:bg-green-800 text-white font-bold text-base"
          >
            {t.browseJobsCta}
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {applications.map((app) => {
            const { bg, Icon } = getStatusStyle(app.status);
            const title = lang === 'hi' ? app.jobTitleHi || app.jobTitleEn : app.jobTitleEn;
            const districtLabel = app.district ? getDistrictLabel(app.district, lang) : '';
            const stateLabel = app.state ? getStateLabel(app.state, lang) : '';
            const appliedDate = app.appliedAt.slice(0, 10);

            const waMessage =
              lang === 'hi'
                ? `नमस्ते, मैंने RuralRise पर "${title}" नौकरी के लिए आवेदन किया है।`
                : `Hello, I applied for "${title}" on RuralRise and wanted to follow up.`;
            const waUrl = app.whatsappNumber
              ? `https://wa.me/91${app.whatsappNumber}?text=${encodeURIComponent(waMessage)}`
              : null;

            return (
              <article
                key={app.id}
                className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4 shadow-sm"
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                  <div className="space-y-1">
                    <h2 className="text-lg font-bold text-slate-950">{title}</h2>
                    {app.employerName && (
                      <p className="text-sm font-medium text-slate-700">{app.employerName}</p>
                    )}
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-slate-600">
                      {districtLabel && (
                        <span className="inline-flex items-center gap-1">
                          <MapPin className="w-4 h-4 text-green-800" aria-hidden="true" />
                          {districtLabel}, {stateLabel}
                        </span>
                      )}
                      {app.monthlySalary && (
                        <span className="font-mono-nums font-bold text-slate-900">
                          {formatRupees(app.monthlySalary, lang)}
                          {t.perMonth}
                        </span>
                      )}
                      {app.accommodationProvided && (
                        <span className="inline-flex items-center gap-1 text-green-900 font-medium">
                          <BedDouble className="w-4 h-4" aria-hidden="true" />
                          {t.freeRoom}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-start shrink-0">
                    <span className="font-mono-nums px-2.5 py-1.5 rounded-xl bg-green-900 text-white text-xs font-bold">
                      {app.matchScore}% {t.matchBadge}
                    </span>
                    <span
                      className={`px-3 py-1.5 rounded-xl border text-sm font-bold inline-flex items-center gap-1.5 ${bg}`}
                    >
                      <Icon className="w-4 h-4" aria-hidden="true" />
                      <span>{STATUS_LABELS[app.status][lang]}</span>
                    </span>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex flex-wrap gap-4 text-sm text-slate-600 font-mono-nums">
                    <span className="inline-flex items-center gap-1.5">
                      <Calendar className="w-4 h-4" aria-hidden="true" />
                      {t.appliedOn}: {appliedDate}
                    </span>
                    <span>
                      {t.availabilityLabel}: {app.availabilityDate}
                    </span>
                  </div>

                  <div className="flex flex-wrap gap-2.5">
                    {waUrl && (
                      <a
                        href={waUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="min-h-[44px] px-3.5 py-2 rounded-xl border border-emerald-700 bg-emerald-50 text-emerald-950 font-semibold text-sm inline-flex items-center gap-1.5 hover:bg-emerald-100"
                      >
                        <MessageCircle className="w-4 h-4" aria-hidden="true" />
                        <span>{t.whatsappConnect}</span>
                      </a>
                    )}

                    <button
                      type="button"
                      onClick={() => void advanceApplicationStatus(app.id)}
                      className="min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-300 bg-slate-50 hover:bg-slate-100 text-slate-900 font-semibold text-sm inline-flex items-center gap-1.5"
                    >
                      <span>{t.advanceStatusDemo}</span>
                      <ArrowRight className="w-4 h-4" aria-hidden="true" />
                    </button>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
