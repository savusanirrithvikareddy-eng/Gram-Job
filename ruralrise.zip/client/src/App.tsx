import { CheckCircle2, Info, WifiOff } from 'lucide-react';
import { HeaderNav } from './components/HeaderNav.tsx';
import { JobDetailModal } from './components/JobDetailModal.tsx';
import { QuickApplyModal } from './components/QuickApplyModal.tsx';
import { AppStateProvider, useAppState } from './context/AppStateContext.tsx';
import { LanguageProvider, useLanguage } from './context/LanguageContext.tsx';
import { ApplicationsPage } from './pages/ApplicationsPage.tsx';
import { JobsPage } from './pages/JobsPage.tsx';
import { PostJobPage } from './pages/PostJobPage.tsx';
import { SkillsPage } from './pages/SkillsPage.tsx';

function MainShell() {
  const { t } = useLanguage();
  const { activeTab, isOffline, toast } = useAppState();

  return (
    <div className="min-h-screen flex flex-col bg-[#F7F8F5] text-slate-900 pb-20 md:pb-8">
      <HeaderNav />

      {isOffline && (
        <div className="bg-amber-100 border-b border-amber-300 text-amber-950 px-4 py-2 text-sm font-semibold flex items-center justify-center gap-2">
          <WifiOff className="w-4 h-4 shrink-0" aria-hidden="true" />
          <span>{t.offlineNotice}</span>
        </div>
      )}

      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 py-5 sm:py-7">
        {activeTab === 'jobs' && <JobsPage />}
        {activeTab === 'skills' && <SkillsPage />}
        {activeTab === 'applications' && <ApplicationsPage />}
        {activeTab === 'post' && <PostJobPage />}
      </main>

      <JobDetailModal />
      <QuickApplyModal />

      {toast && (
        <div
          role="status"
          aria-live="polite"
          className={`fixed bottom-20 md:bottom-6 right-4 left-4 sm:left-auto sm:max-w-md z-50 px-4 py-3.5 rounded-2xl shadow-lg border font-semibold text-sm sm:text-base flex items-center gap-2.5 ${
            toast.tone === 'success'
              ? 'bg-emerald-950 text-white border-emerald-800'
              : 'bg-slate-900 text-white border-slate-700'
          }`}
        >
          {toast.tone === 'success' ? (
            <CheckCircle2 className="w-5 h-5 text-amber-400 shrink-0" aria-hidden="true" />
          ) : (
            <Info className="w-5 h-5 text-amber-400 shrink-0" aria-hidden="true" />
          )}
          <span>{toast.message}</span>
        </div>
      )}
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <AppStateProvider>
        <MainShell />
      </AppStateProvider>
    </LanguageProvider>
  );
}
