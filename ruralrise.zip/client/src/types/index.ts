export type Language = 'hi' | 'en';

export type TradeCategoryId =
  | 'solar'
  | 'electrical'
  | 'mechanical'
  | 'agritech'
  | 'welding'
  | 'agriculture'
  | 'retail'
  | 'healthcare'
  | 'banking';

export type EmployerType =
  | 'rural_enterprise'
  | 'agritech_startup'
  | 'solar_epc'
  | 'local_distributor';

export type CertificateType = 'ITI' | 'PMKVY' | 'Diploma';

export type ApplicationStatus =
  | 'Applied'
  | 'Under Review'
  | 'Interview Call'
  | 'Selected'
  | 'Not Selected';

export interface TradeCategory {
  id: TradeCategoryId;
  nameEn: string;
  nameHi: string;
  iconName: string;
  descriptionEn: string;
  descriptionHi: string;
}

export interface VocationalSkill {
  id: string;
  tradeId: TradeCategoryId;
  nameEn: string;
  nameHi: string;
  relatedSkillIds: string[];
}

export interface CandidateSkill {
  skillId: string;
  tradeId: TradeCategoryId;
  years: number;
  certified: boolean;
  certificateType: CertificateType;
}

export interface CandidateProfile {
  id: string;
  name: string;
  phone: string;
  phoneVerified: boolean;
  district: string;
  state: string;
  skills: CandidateSkill[];
  updatedAt: string;
}

export interface JobVacancy {
  id: string;
  titleEn: string;
  titleHi: string;
  employerName: string;
  employerType: EmployerType;
  district: string;
  state: string;
  tradeCategory: TradeCategoryId;
  requiredSkills: string[];
  optionalSkills: string[];
  minExperienceYears: number;
  certificationPreferred: boolean;
  monthlySalary: number;
  foodProvided: boolean;
  accommodationProvided: boolean;
  responsibilitiesEn: string[];
  responsibilitiesHi: string[];
  whatsappNumber: string;
  postedDate: string;
}

export interface SkillMatchResult {
  score: number;
  matchedSkills: string[];
  relatedSkills: string[];
  missingSkills: string[];
  experienceBonus: number;
  certificationBonus: number;
}

export interface JobWithMatch extends JobVacancy {
  match: SkillMatchResult;
  distanceKm: number | null;
}

export interface JobApplication {
  id: string;
  jobId: string;
  candidateId: string;
  phone: string;
  availabilityDate: string;
  matchScore: number;
  status: ApplicationStatus;
  appliedAt: string;
  updatedAt: string;
  jobTitleEn?: string;
  jobTitleHi?: string;
  employerName?: string;
  district?: string;
  state?: string;
  monthlySalary?: number;
  accommodationProvided?: boolean;
  whatsappNumber?: string;
}

export interface FraudReport {
  id: string;
  jobId: string;
  reason: string;
  details: string;
  reportedAt: string;
}
