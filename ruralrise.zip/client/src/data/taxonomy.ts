import type { TradeCategory, TradeCategoryId, VocationalSkill } from '../types/index.ts';

export const TRADE_CATEGORIES: TradeCategory[] = [
  {
    id: 'solar',
    nameEn: 'Solar',
    nameHi: 'सौर ऊर्जा',
    iconName: 'Sun',
    descriptionEn: 'Rooftop PV, solar pumps & inverters',
    descriptionHi: 'रूफटॉप सोलर, सोलर पंप और इन्वर्टर',
  },
  {
    id: 'electrical',
    nameEn: 'Electrical',
    nameHi: 'इलेक्ट्रिकल',
    iconName: 'Zap',
    descriptionEn: 'House wiring, motors & panels',
    descriptionHi: 'घरेलू वायरिंग, मोटर और पैनल',
  },
  {
    id: 'mechanical',
    nameEn: 'Mechanical',
    nameHi: 'मैकेनिकल',
    iconName: 'Wrench',
    descriptionEn: 'Tractors, e-rickshaws & mobile repair',
    descriptionHi: 'ट्रैक्टर, ई-रिक्शा और मोबाइल रिपेयर',
  },
  {
    id: 'agritech',
    nameEn: 'Agri-tech',
    nameHi: 'एग्री-टेक',
    iconName: 'Sprout',
    descriptionEn: 'Drip irrigation, cold storage & processing',
    descriptionHi: 'ड्रिप सिंचाई, कोल्ड स्टोरेज और प्रसंस्करण',
  },
  {
    id: 'welding',
    nameEn: 'Welding',
    nameHi: 'वेल्डिंग',
    iconName: 'Flame',
    descriptionEn: 'Arc/gas welding & steel framing',
    descriptionHi: 'आर्क/गैस वेल्डिंग और मेटल फ्रेमिंग',
  },
  {
    id: 'agriculture',
    nameEn: 'Agriculture',
    nameHi: 'कृषि एवं डेयरी',
    iconName: 'Tractor',
    descriptionEn: 'Dairy handling, organic farming & grain',
    descriptionHi: 'डेयरी प्रबंधन, जैविक खेती और अनाज',
  },
  {
    id: 'retail',
    nameEn: 'Retail',
    nameHi: 'रिटेल और बिक्री',
    iconName: 'Store',
    descriptionEn: 'Distributor sales & stock billing',
    descriptionHi: 'डिस्ट्रीब्यूटर बिक्री और स्टॉक बिलिंग',
  },
  {
    id: 'healthcare',
    nameEn: 'Healthcare',
    nameHi: 'स्वास्थ्य सेवा',
    iconName: 'HeartPulse',
    descriptionEn: 'Nursing aid & clinic patient care',
    descriptionHi: 'नर्सिंग सहायता और रोगी देखभाल',
  },
  {
    id: 'banking',
    nameEn: 'Banking/Finance',
    nameHi: 'बैंकिंग और वित्त',
    iconName: 'Landmark',
    descriptionEn: 'Bank Mitra & digital AEPS services',
    descriptionHi: 'बैंक मित्र और डिजिटल सेवाएं',
  },
];

export const VOCATIONAL_SKILLS: VocationalSkill[] = [
  {
    id: 'solar_pv_installation',
    tradeId: 'solar',
    nameEn: 'Solar PV Installation',
    nameHi: 'सोलर पीवी इंस्टॉलेशन',
    relatedSkillIds: [
      'electrical_wiring',
      'solar_pump_maintenance',
      'inverter_battery_setup',
      'earthing_safety',
      'metal_fabrication',
    ],
  },
  {
    id: 'solar_pump_maintenance',
    tradeId: 'solar',
    nameEn: 'Solar Pump Maintenance',
    nameHi: 'सोलर पंप रखरखाव',
    relatedSkillIds: [
      'solar_pv_installation',
      'motor_winding',
      'drip_irrigation',
      'electrical_wiring',
    ],
  },
  {
    id: 'inverter_battery_setup',
    tradeId: 'solar',
    nameEn: 'Inverter & Battery Setup',
    nameHi: 'इन्वर्टर और बैटरी सेटअप',
    relatedSkillIds: [
      'solar_pv_installation',
      'electrical_wiring',
      'earthing_safety',
      'e_rickshaw_repair',
    ],
  },
  {
    id: 'electrical_wiring',
    tradeId: 'electrical',
    nameEn: 'Electrical Wiring',
    nameHi: 'इलेक्ट्रिकल वायरिंग',
    relatedSkillIds: [
      'solar_pv_installation',
      'inverter_battery_setup',
      'earthing_safety',
      'motor_winding',
      'e_rickshaw_repair',
    ],
  },
  {
    id: 'motor_winding',
    tradeId: 'electrical',
    nameEn: 'Motor Winding & Panels',
    nameHi: 'मोटर वाइंडिंग और पैनल',
    relatedSkillIds: [
      'electrical_wiring',
      'solar_pump_maintenance',
      'mill_machine_operation',
      'cold_storage_ops',
    ],
  },
  {
    id: 'earthing_safety',
    tradeId: 'electrical',
    nameEn: 'Earthing & Safety Check',
    nameHi: 'अर्थिंग और सुरक्षा जांच',
    relatedSkillIds: ['electrical_wiring', 'solar_pv_installation', 'inverter_battery_setup'],
  },
  {
    id: 'tractor_maintenance',
    tradeId: 'mechanical',
    nameEn: 'Tractor Maintenance',
    nameHi: 'ट्रैक्टर मरम्मत',
    relatedSkillIds: ['e_rickshaw_repair', 'mill_machine_operation', 'welding'],
  },
  {
    id: 'e_rickshaw_repair',
    tradeId: 'mechanical',
    nameEn: 'E-Rickshaw Repair',
    nameHi: 'ई-रिक्शा मरम्मत',
    relatedSkillIds: [
      'tractor_maintenance',
      'electrical_wiring',
      'inverter_battery_setup',
      'motor_winding',
    ],
  },
  {
    id: 'mobile_hardware_repair',
    tradeId: 'mechanical',
    nameEn: 'Mobile Hardware Repair',
    nameHi: 'मोबाइल हार्डवेयर रिपेयर',
    relatedSkillIds: ['electrical_wiring', 'inverter_battery_setup'],
  },
  {
    id: 'mill_machine_operation',
    tradeId: 'mechanical',
    nameEn: 'Mill & Plant Operation',
    nameHi: 'मिल और प्लांट मशीन संचालन',
    relatedSkillIds: ['agro_processing', 'motor_winding', 'tractor_maintenance', 'cold_storage_ops'],
  },
  {
    id: 'drip_irrigation',
    tradeId: 'agritech',
    nameEn: 'Drip Irrigation',
    nameHi: 'ड्रिप सिंचाई प्रणाली',
    relatedSkillIds: ['solar_pump_maintenance', 'organic_farming', 'soil_crop_advisory'],
  },
  {
    id: 'agro_processing',
    tradeId: 'agritech',
    nameEn: 'Agro-Processing',
    nameHi: 'कृषि प्रसंस्करण',
    relatedSkillIds: ['mill_machine_operation', 'dairy_handling', 'grain_grading', 'cold_storage_ops'],
  },
  {
    id: 'cold_storage_ops',
    tradeId: 'agritech',
    nameEn: 'Cold Storage Control',
    nameHi: 'कोल्ड स्टोरेज संचालन',
    relatedSkillIds: ['agro_processing', 'motor_winding', 'dairy_handling', 'mill_machine_operation'],
  },
  {
    id: 'soil_crop_advisory',
    tradeId: 'agritech',
    nameEn: 'Soil & Crop Advisory',
    nameHi: 'मिट्टी जांच और फसल सलाह',
    relatedSkillIds: ['organic_farming', 'drip_irrigation', 'retail_sales'],
  },
  {
    id: 'welding',
    tradeId: 'welding',
    nameEn: 'Welding',
    nameHi: 'वेल्डिंग',
    relatedSkillIds: ['metal_fabrication', 'tractor_maintenance', 'solar_pv_installation'],
  },
  {
    id: 'metal_fabrication',
    tradeId: 'welding',
    nameEn: 'Metal Fabrication',
    nameHi: 'धातु फैब्रिकेशन',
    relatedSkillIds: ['welding', 'solar_pv_installation'],
  },
  {
    id: 'dairy_handling',
    tradeId: 'agriculture',
    nameEn: 'Dairy Handling',
    nameHi: 'डेयरी प्रबंधन',
    relatedSkillIds: ['agro_processing', 'cold_storage_ops', 'organic_farming'],
  },
  {
    id: 'organic_farming',
    tradeId: 'agriculture',
    nameEn: 'Organic Farming',
    nameHi: 'जैविक खेती',
    relatedSkillIds: ['soil_crop_advisory', 'drip_irrigation', 'dairy_handling'],
  },
  {
    id: 'grain_grading',
    tradeId: 'agriculture',
    nameEn: 'Grain Grading & Storage',
    nameHi: 'अनाज ग्रेडिंग और भंडारण',
    relatedSkillIds: ['agro_processing', 'mill_machine_operation', 'inventory_billing'],
  },
  {
    id: 'retail_sales',
    tradeId: 'retail',
    nameEn: 'Retail Distributor Sales',
    nameHi: 'रिटेल और डिस्ट्रीब्यूटर बिक्री',
    relatedSkillIds: ['inventory_billing', 'soil_crop_advisory', 'banking_correspondent'],
  },
  {
    id: 'inventory_billing',
    tradeId: 'retail',
    nameEn: 'Stock & Billing Entry',
    nameHi: 'स्टॉक और बिलिंग कार्य',
    relatedSkillIds: ['retail_sales', 'digital_payments', 'grain_grading'],
  },
  {
    id: 'nursing_aid',
    tradeId: 'healthcare',
    nameEn: 'Nursing Aid',
    nameHi: 'नर्सिंग सहायता',
    relatedSkillIds: ['first_aid_vitals'],
  },
  {
    id: 'first_aid_vitals',
    tradeId: 'healthcare',
    nameEn: 'First Aid & Vitals',
    nameHi: 'प्राथमिक उपचार और जांच',
    relatedSkillIds: ['nursing_aid'],
  },
  {
    id: 'banking_correspondent',
    tradeId: 'banking',
    nameEn: 'Banking Correspondent Work',
    nameHi: 'बैंकिंग कॉरेस्पोंडेंट (बैंक मित्र)',
    relatedSkillIds: ['digital_payments', 'retail_sales', 'inventory_billing'],
  },
  {
    id: 'digital_payments',
    tradeId: 'banking',
    nameEn: 'AEPS & Digital KYC',
    nameHi: 'आधार एईपीएस और डिजिटल केवाईसी',
    relatedSkillIds: ['banking_correspondent', 'inventory_billing'],
  },
];

export const SKILL_MAP: Record<string, VocationalSkill> = Object.fromEntries(
  VOCATIONAL_SKILLS.map((skill) => [skill.id, skill])
);

export const TRADE_MAP: Record<TradeCategoryId, TradeCategory> = Object.fromEntries(
  TRADE_CATEGORIES.map((trade) => [trade.id, trade])
) as Record<TradeCategoryId, TradeCategory>;

export function getSkillLabel(skillId: string, lang: 'hi' | 'en'): string {
  const skill = SKILL_MAP[skillId];
  if (!skill) return skillId;
  return lang === 'hi' ? skill.nameHi : skill.nameEn;
}

export function getTradeLabel(tradeId: TradeCategoryId, lang: 'hi' | 'en'): string {
  const trade = TRADE_MAP[tradeId];
  if (!trade) return tradeId;
  return lang === 'hi' ? trade.nameHi : trade.nameEn;
}
