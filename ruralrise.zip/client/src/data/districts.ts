export interface DistrictInfo {
  district: string;
  districtHi: string;
  state: string;
  stateHi: string;
  lat: number;
  lng: number;
}

export const DISTRICTS: DistrictInfo[] = [
  { district: 'Jaipur', districtHi: 'जयपुर', state: 'Rajasthan', stateHi: 'राजस्थान', lat: 26.9124, lng: 75.7873 },
  { district: 'Sikar', districtHi: 'सीकर', state: 'Rajasthan', stateHi: 'राजस्थान', lat: 27.6094, lng: 75.1398 },
  { district: 'Jodhpur', districtHi: 'जोधपुर', state: 'Rajasthan', stateHi: 'राजस्थान', lat: 26.2389, lng: 73.0243 },
  { district: 'Udaipur', districtHi: 'उदयपुर', state: 'Rajasthan', stateHi: 'राजस्थान', lat: 24.5854, lng: 73.7125 },
  { district: 'Kota', districtHi: 'कोटा', state: 'Rajasthan', stateHi: 'राजस्थान', lat: 25.2138, lng: 75.8648 },
  { district: 'Lucknow', districtHi: 'लखनऊ', state: 'Uttar Pradesh', stateHi: 'उत्तर प्रदेश', lat: 26.8467, lng: 80.9462 },
  { district: 'Barabanki', districtHi: 'बाराबंकी', state: 'Uttar Pradesh', stateHi: 'उत्तर प्रदेश', lat: 26.9239, lng: 81.1904 },
  { district: 'Varanasi', districtHi: 'वाराणसी', state: 'Uttar Pradesh', stateHi: 'उत्तर प्रदेश', lat: 25.3176, lng: 82.9739 },
  { district: 'Indore', districtHi: 'इंदौर', state: 'Madhya Pradesh', stateHi: 'मध्य प्रदेश', lat: 22.7196, lng: 75.8577 },
  { district: 'Bhopal', districtHi: 'भोपाल', state: 'Madhya Pradesh', stateHi: 'मध्य प्रदेश', lat: 23.2599, lng: 77.4126 },
  { district: 'Patna', districtHi: 'पटना', state: 'Bihar', stateHi: 'बिहार', lat: 25.5941, lng: 85.1376 },
  { district: 'Muzaffarpur', districtHi: 'मुजफ्फरपुर', state: 'Bihar', stateHi: 'बिहार', lat: 26.1209, lng: 85.3647 },
  { district: 'Gaya', districtHi: 'गया', state: 'Bihar', stateHi: 'बिहार', lat: 24.7914, lng: 85.0002 },
  { district: 'Anand', districtHi: 'आणंद', state: 'Gujarat', stateHi: 'गुजरात', lat: 22.5645, lng: 72.9289 },
  { district: 'Rajkot', districtHi: 'राजकोट', state: 'Gujarat', stateHi: 'गुजरात', lat: 22.3039, lng: 70.8022 },
  { district: 'Nashik', districtHi: 'नासिक', state: 'Maharashtra', stateHi: 'महाराष्ट्र', lat: 19.9975, lng: 73.7898 },
  { district: 'Pune', districtHi: 'पुणे', state: 'Maharashtra', stateHi: 'महाराष्ट्र', lat: 18.5204, lng: 73.8567 },
  { district: 'Nagpur', districtHi: 'नागपुर', state: 'Maharashtra', stateHi: 'महाराष्ट्र', lat: 21.1458, lng: 79.0882 },
];

export const DISTRICT_MAP: Record<string, DistrictInfo> = Object.fromEntries(
  DISTRICTS.map((d) => [d.district.toLowerCase(), d])
);

export const STATES_LIST = Array.from(new Set(DISTRICTS.map((d) => d.state)));

export function getDistrictLabel(districtName: string, lang: 'hi' | 'en'): string {
  const found = DISTRICT_MAP[districtName.toLowerCase()];
  if (!found) return districtName;
  return lang === 'hi' ? found.districtHi : found.district;
}

export function getStateLabel(stateName: string, lang: 'hi' | 'en'): string {
  const found = DISTRICTS.find((d) => d.state.toLowerCase() === stateName.toLowerCase());
  if (!found) return stateName;
  return lang === 'hi' ? found.stateHi : found.state;
}

function toRad(deg: number): number {
  return (deg * Math.PI) / 180;
}

/**
 * Computes approximate road distance (1.18x straight-line Haversine) between two Indian districts.
 */
export function computeDistrictDistanceKm(homeDistrict: string, jobDistrict: string): number | null {
  if (!homeDistrict || !jobDistrict) return null;
  const a = DISTRICT_MAP[homeDistrict.trim().toLowerCase()];
  const b = DISTRICT_MAP[jobDistrict.trim().toLowerCase()];
  if (!a || !b) return null;
  if (a.district === b.district) return 0;

  const R = 6371;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const sinLat = Math.sin(dLat / 2);
  const sinLng = Math.sin(dLng / 2);
  const h =
    sinLat * sinLat +
    Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * sinLng * sinLng;
  const straightKm = 2 * R * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
  return Math.round((straightKm * 1.18) / 5) * 5;
}
