import { computeDistrictDistanceKm } from '../data/districts.ts';
import { SEED_JOBS } from '../data/seedJobs.ts';
import type {
  ApplicationStatus,
  CandidateProfile,
  FraudReport,
  JobApplication,
  JobVacancy,
  JobWithMatch,
} from '../types/index.ts';
import { computeSkillMatch } from './matcher.ts';

const LS_JOBS_KEY = 'ruralrise_jobs_v1';
const LS_CANDIDATE_KEY = 'ruralrise_candidate_v1';
const LS_APPS_KEY = 'ruralrise_applications_v1';
const LS_REPORTS_KEY = 'ruralrise_reports_v1';

function readJson<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function writeJson<T>(key: string, data: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch {
    // Ignore storage quota errors
  }
}

function getLocalJobs(): JobVacancy[] {
  const stored = readJson<JobVacancy[] | null>(LS_JOBS_KEY, null);
  if (stored && stored.length > 0) return stored;
  writeJson(LS_JOBS_KEY, SEED_JOBS);
  return SEED_JOBS;
}

export function getStoredCandidate(): CandidateProfile | null {
  return readJson<CandidateProfile | null>(LS_CANDIDATE_KEY, null);
}

export function storeCandidateLocally(profile: CandidateProfile): void {
  writeJson(LS_CANDIDATE_KEY, profile);
}

function enrichLocally(jobs: JobVacancy[], candidate: CandidateProfile | null): JobWithMatch[] {
  return jobs.map((job) => ({
    ...job,
    match: computeSkillMatch(candidate?.skills ?? [], job),
    distanceKm: candidate?.district
      ? computeDistrictDistanceKm(candidate.district, job.district)
      : null,
  }));
}

export interface JobsQueryParams {
  candidateId?: string;
  candidate?: CandidateProfile | null;
  search?: string;
  trade?: string;
  district?: string;
  minSalary?: number;
  accommodationOnly?: boolean;
  sort?: 'match' | 'salary' | 'distance';
}

export async function fetchJobs(
  params: JobsQueryParams
): Promise<{ jobs: JobWithMatch[]; offline: boolean }> {
  const query = new URLSearchParams();
  if (params.candidateId) query.set('candidateId', params.candidateId);
  if (params.search) query.set('search', params.search);
  if (params.trade && params.trade !== 'all') query.set('trade', params.trade);
  if (params.district && params.district !== 'all') query.set('district', params.district);
  if (params.minSalary && params.minSalary > 0) query.set('minSalary', String(params.minSalary));
  if (params.accommodationOnly) query.set('accommodationOnly', 'true');
  if (params.sort) query.set('sort', params.sort);

  try {
    const res = await fetch(`/api/jobs?${query.toString()}`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = (await res.json()) as { jobs: JobWithMatch[] };
    writeJson(
      LS_JOBS_KEY,
      data.jobs.map(({ match: _m, distanceKm: _d, ...rest }) => rest)
    );
    return { jobs: data.jobs, offline: false };
  } catch {
    let list = enrichLocally(getLocalJobs(), params.candidate ?? getStoredCandidate());
    const search = (params.search ?? '').trim().toLowerCase();
    if (search) {
      list = list.filter(
        (j) =>
          j.titleEn.toLowerCase().includes(search) ||
          j.titleHi.toLowerCase().includes(search) ||
          j.employerName.toLowerCase().includes(search) ||
          j.district.toLowerCase().includes(search) ||
          j.tradeCategory.toLowerCase().includes(search)
      );
    }
    if (params.trade && params.trade !== 'all') {
      list = list.filter((j) => j.tradeCategory === params.trade);
    }
    if (params.district && params.district !== 'all') {
      list = list.filter((j) => j.district.toLowerCase() === params.district!.toLowerCase());
    }
    if (params.minSalary && params.minSalary > 0) {
      list = list.filter((j) => j.monthlySalary >= params.minSalary!);
    }
    if (params.accommodationOnly) {
      list = list.filter((j) => j.accommodationProvided);
    }
    list.sort((a, b) => {
      if (params.sort === 'salary') return b.monthlySalary - a.monthlySalary;
      if (params.sort === 'distance') {
        return (a.distanceKm ?? 99999) - (b.distanceKm ?? 99999);
      }
      return b.match.score - a.match.score || b.monthlySalary - a.monthlySalary;
    });
    return { jobs: list, offline: true };
  }
}

export async function saveCandidateApi(
  profile: CandidateProfile
): Promise<{ profile: CandidateProfile; offline: boolean }> {
  storeCandidateLocally(profile);
  try {
    const res = await fetch('/api/candidates', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(profile),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const saved = (await res.json()) as CandidateProfile;
    storeCandidateLocally(saved);
    return { profile: saved, offline: false };
  } catch {
    return { profile, offline: true };
  }
}

export async function createJobApi(
  input: Omit<JobVacancy, 'id' | 'postedDate'>
): Promise<{ job: JobVacancy; offline: boolean }> {
  try {
    const res = await fetch('/api/jobs', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input),
    });
    if (!res.ok) {
      const errData = (await res.json().catch(() => ({}))) as { error?: string };
      throw new Error(errData.error || `HTTP ${res.status}`);
    }
    const created = (await res.json()) as JobVacancy;
    const local = getLocalJobs();
    writeJson(LS_JOBS_KEY, [created, ...local.filter((j) => j.id !== created.id)]);
    return { job: created, offline: false };
  } catch {
    const fallbackJob: JobVacancy = {
      ...input,
      id: `job-local-${Date.now()}`,
      postedDate: new Date().toISOString().slice(0, 10),
    };
    const local = getLocalJobs();
    writeJson(LS_JOBS_KEY, [fallbackJob, ...local]);
    return { job: fallbackJob, offline: true };
  }
}

export async function fetchApplicationsApi(
  candidateId: string
): Promise<{ applications: JobApplication[]; offline: boolean }> {
  try {
    const res = await fetch(`/api/applications?candidateId=${encodeURIComponent(candidateId)}`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = (await res.json()) as { applications: JobApplication[] };
    writeJson(LS_APPS_KEY, data.applications);
    return { applications: data.applications, offline: false };
  } catch {
    const all = readJson<JobApplication[]>(LS_APPS_KEY, []);
    return {
      applications: all.filter((a) => a.candidateId === candidateId),
      offline: true,
    };
  }
}

export async function submitApplicationApi(payload: {
  job: JobWithMatch;
  candidateId: string;
  phone: string;
  availabilityDate: string;
}): Promise<{ application: JobApplication; offline: boolean }> {
  try {
    const res = await fetch('/api/applications', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        jobId: payload.job.id,
        candidateId: payload.candidateId,
        phone: payload.phone,
        availabilityDate: payload.availabilityDate,
        matchScore: payload.job.match.score,
      }),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const created = (await res.json()) as JobApplication;
    const existing = readJson<JobApplication[]>(LS_APPS_KEY, []);
    writeJson(LS_APPS_KEY, [created, ...existing.filter((a) => a.id !== created.id)]);
    return { application: created, offline: false };
  } catch {
    const now = new Date().toISOString();
    const localApp: JobApplication = {
      id: `app-local-${Date.now()}`,
      jobId: payload.job.id,
      candidateId: payload.candidateId,
      phone: payload.phone,
      availabilityDate: payload.availabilityDate,
      matchScore: payload.job.match.score,
      status: 'Applied',
      appliedAt: now,
      updatedAt: now,
      jobTitleEn: payload.job.titleEn,
      jobTitleHi: payload.job.titleHi,
      employerName: payload.job.employerName,
      district: payload.job.district,
      state: payload.job.state,
      monthlySalary: payload.job.monthlySalary,
      accommodationProvided: payload.job.accommodationProvided,
      whatsappNumber: payload.job.whatsappNumber,
    };
    const existing = readJson<JobApplication[]>(LS_APPS_KEY, []);
    const filtered = existing.filter(
      (a) => !(a.jobId === payload.job.id && a.candidateId === payload.candidateId)
    );
    writeJson(LS_APPS_KEY, [localApp, ...filtered]);
    return { application: localApp, offline: true };
  }
}

export async function updateApplicationStatusApi(
  applicationId: string,
  status: ApplicationStatus
): Promise<{ application: JobApplication | null; offline: boolean }> {
  try {
    const res = await fetch(`/api/applications/${encodeURIComponent(applicationId)}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const updated = (await res.json()) as JobApplication;
    const existing = readJson<JobApplication[]>(LS_APPS_KEY, []);
    writeJson(
      LS_APPS_KEY,
      existing.map((a) => (a.id === updated.id ? updated : a))
    );
    return { application: updated, offline: false };
  } catch {
    const existing = readJson<JobApplication[]>(LS_APPS_KEY, []);
    let updatedItem: JobApplication | null = null;
    const next = existing.map((a) => {
      if (a.id === applicationId) {
        updatedItem = { ...a, status, updatedAt: new Date().toISOString() };
        return updatedItem;
      }
      return a;
    });
    writeJson(LS_APPS_KEY, next);
    return { application: updatedItem, offline: true };
  }
}

export async function submitReportApi(
  jobId: string,
  reason: string,
  details: string
): Promise<void> {
  try {
    const res = await fetch('/api/reports', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ jobId, reason, details }),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
  } catch {
    const existing = readJson<FraudReport[]>(LS_REPORTS_KEY, []);
    existing.push({
      id: `rep-local-${Date.now()}`,
      jobId,
      reason,
      details,
      reportedAt: new Date().toISOString(),
    });
    writeJson(LS_REPORTS_KEY, existing);
  }
}
