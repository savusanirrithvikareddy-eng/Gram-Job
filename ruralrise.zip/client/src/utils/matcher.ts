import { SKILL_MAP } from '../data/taxonomy.ts';
import type { CandidateSkill, JobVacancy, SkillMatchResult } from '../types/index.ts';

function areSkillsRelated(skillA: string, skillB: string): boolean {
  const a = SKILL_MAP[skillA];
  const b = SKILL_MAP[skillB];
  if (!a || !b) return false;
  return (
    a.relatedSkillIds.includes(skillB) ||
    b.relatedSkillIds.includes(skillA) ||
    a.tradeId === b.tradeId
  );
}

/**
 * Weighted vocational skill overlap heuristic (0-100%).
 * - Required skills carry 65 points (1.0 exact, 0.5 related skill in taxonomy).
 * - Optional skills carry 15 points (1.0 exact, 0.7 related to candidate's core skills).
 * - Experience bonus carries up to 10 points when relevant years meet/exceed job minimum.
 * - Certification bonus carries up to 10 points when candidate holds ITI/PMKVY/Diploma on relevant skills.
 * Experience and certification bonuses scale down if the candidate has minimal skill overlap so
 * unrelated jobs never score artificially high.
 */
export function computeSkillMatch(
  candidateSkills: CandidateSkill[],
  job: Pick<
    JobVacancy,
    'requiredSkills' | 'optionalSkills' | 'minExperienceYears' | 'certificationPreferred'
  >
): SkillMatchResult {
  if (!candidateSkills || candidateSkills.length === 0) {
    return {
      score: 0,
      matchedSkills: [],
      relatedSkills: [],
      missingSkills: [...job.requiredSkills],
      experienceBonus: 0,
      certificationBonus: 0,
    };
  }

  const candidateSkillMap = new Map<string, CandidateSkill>(
    candidateSkills.map((s) => [s.skillId, s])
  );

  const matchedSkills: string[] = [];
  const relatedSkills: string[] = [];
  const missingSkills: string[] = [];

  let requiredCredit = 0;
  let relevantMaxYears = 0;
  let hasRelevantCertification = false;

  for (const reqSkill of job.requiredSkills) {
    const exact = candidateSkillMap.get(reqSkill);
    if (exact) {
      requiredCredit += 1;
      matchedSkills.push(reqSkill);
      relevantMaxYears = Math.max(relevantMaxYears, exact.years);
      if (exact.certified) hasRelevantCertification = true;
      continue;
    }

    const relatedCandidate = candidateSkills.find((cs) => areSkillsRelated(cs.skillId, reqSkill));
    if (relatedCandidate) {
      requiredCredit += 0.5;
      relatedSkills.push(reqSkill);
      relevantMaxYears = Math.max(relevantMaxYears, relatedCandidate.years);
      if (relatedCandidate.certified) hasRelevantCertification = true;
    } else {
      missingSkills.push(reqSkill);
    }
  }

  const reqTotal = Math.max(job.requiredSkills.length, 1);
  const requiredPoints = (requiredCredit / reqTotal) * 65;

  let optionalCredit = 0;
  for (const optSkill of job.optionalSkills) {
    const exact = candidateSkillMap.get(optSkill);
    if (exact) {
      optionalCredit += 1;
      matchedSkills.push(optSkill);
      relevantMaxYears = Math.max(relevantMaxYears, exact.years);
      if (exact.certified) hasRelevantCertification = true;
      continue;
    }

    const relatedCandidate = candidateSkills.find((cs) => areSkillsRelated(cs.skillId, optSkill));
    if (relatedCandidate) {
      optionalCredit += 0.7;
      if (relatedCandidate.certified) hasRelevantCertification = true;
    }
  }

  const optionalPoints =
    job.optionalSkills.length > 0 ? (optionalCredit / job.optionalSkills.length) * 15 : 15;

  const rawOverlap = requiredPoints + optionalPoints;
  const relevanceGate = Math.min(1, rawOverlap / 30);

  let rawExperienceBonus = 0;
  if (relevantMaxYears > job.minExperienceYears) {
    rawExperienceBonus = 10;
  } else if (relevantMaxYears >= job.minExperienceYears) {
    rawExperienceBonus = 9.5;
  } else if (job.minExperienceYears > 0 && relevantMaxYears > 0) {
    rawExperienceBonus = (relevantMaxYears / job.minExperienceYears) * 6;
  }

  let rawCertBonus = 0;
  if (hasRelevantCertification) {
    rawCertBonus = job.certificationPreferred ? 10 : 8;
  }

  const experienceBonus = Math.round(rawExperienceBonus * relevanceGate * 10) / 10;
  const certificationBonus = Math.round(rawCertBonus * relevanceGate * 10) / 10;

  const rawScore = rawOverlap + experienceBonus + certificationBonus;
  const score = Math.max(0, Math.min(100, Math.round(rawScore)));

  return {
    score,
    matchedSkills: Array.from(new Set(matchedSkills)),
    relatedSkills: Array.from(new Set(relatedSkills)),
    missingSkills: Array.from(new Set(missingSkills)),
    experienceBonus: Math.round(experienceBonus),
    certificationBonus: Math.round(certificationBonus),
  };
}
